/****************************************************************************
** Meta object code from reading C++ file 'qwt_designer_plugin.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../src/3rdParty/qwt/designer/qwt_designer_plugin.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/qplugin.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qwt_designer_plugin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface_t {
    QByteArrayData data[1];
    char stringdata0[41];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface_t qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface = {
    {
QT_MOC_LITERAL(0, 0, 40) // "QwtDesignerPlugin::CustomWidg..."

    },
    "QwtDesignerPlugin::CustomWidgetInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CustomWidgetInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CustomWidgetInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CustomWidgetInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface.data,
      qt_meta_data_QwtDesignerPlugin__CustomWidgetInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::CustomWidgetInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CustomWidgetInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return QObject::qt_metacast(_clname);
}

int QwtDesignerPlugin::CustomWidgetInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface_t {
    QByteArrayData data[1];
    char stringdata0[51];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface_t qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface = {
    {
QT_MOC_LITERAL(0, 0, 50) // "QwtDesignerPlugin::CustomWidg..."

    },
    "QwtDesignerPlugin::CustomWidgetCollectionInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CustomWidgetCollectionInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CustomWidgetCollectionInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CustomWidgetCollectionInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface.data,
      qt_meta_data_QwtDesignerPlugin__CustomWidgetCollectionInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::CustomWidgetCollectionInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CustomWidgetCollectionInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CustomWidgetCollectionInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QDesignerCustomWidgetCollectionInterface"))
        return static_cast< QDesignerCustomWidgetCollectionInterface*>(this);
    if (!strcmp(_clname, "org.qt-project.Qt.QDesignerCustomWidgetCollectionInterface"))
        return static_cast< QDesignerCustomWidgetCollectionInterface*>(this);
    return QObject::qt_metacast(_clname);
}

int QwtDesignerPlugin::CustomWidgetCollectionInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}

QT_PLUGIN_METADATA_SECTION const uint qt_section_alignment_dummy = 42;

#ifdef QT_NO_DEBUG

QT_PLUGIN_METADATA_SECTION
static const unsigned char qt_pluginMetaData[] = {
    'Q', 'T', 'M', 'E', 'T', 'A', 'D', 'A', 'T', 'A', ' ', ' ',
    'q',  'b',  'j',  's',  0x01, 0x00, 0x00, 0x00,
    0xd4, 0x00, 0x00, 0x00, 0x0b, 0x00, 0x00, 0x00,
    0xc0, 0x00, 0x00, 0x00, 0x1b, 0x03, 0x00, 0x00,
    0x03, 0x00, 'I',  'I',  'D',  0x00, 0x00, 0x00,
    ':',  0x00, 'o',  'r',  'g',  '.',  'q',  't', 
    '-',  'p',  'r',  'o',  'j',  'e',  'c',  't', 
    '.',  'Q',  't',  '.',  'Q',  'D',  'e',  's', 
    'i',  'g',  'n',  'e',  'r',  'C',  'u',  's', 
    't',  'o',  'm',  'W',  'i',  'd',  'g',  'e', 
    't',  'C',  'o',  'l',  'l',  'e',  'c',  't', 
    'i',  'o',  'n',  'I',  'n',  't',  'e',  'r', 
    'f',  'a',  'c',  'e',  0x9b, 0x0c, 0x00, 0x00,
    0x09, 0x00, 'c',  'l',  'a',  's',  's',  'N', 
    'a',  'm',  'e',  0x00, 0x1f, 0x00, 'C',  'u', 
    's',  't',  'o',  'm',  'W',  'i',  'd',  'g', 
    'e',  't',  'C',  'o',  'l',  'l',  'e',  'c', 
    't',  'i',  'o',  'n',  'I',  'n',  't',  'e', 
    'r',  'f',  'a',  'c',  'e',  0x00, 0x00, 0x00,
    ':',  '!',  0xa1, 0x00, 0x07, 0x00, 'v',  'e', 
    'r',  's',  'i',  'o',  'n',  0x00, 0x00, 0x00,
    0x11, 0x00, 0x00, 0x00, 0x05, 0x00, 'd',  'e', 
    'b',  'u',  'g',  0x00, 0x95, 0x16, 0x00, 0x00,
    0x08, 0x00, 'M',  'e',  't',  'a',  'D',  'a', 
    't',  'a',  0x00, 0x00, 0x0c, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x0c, 0x00, 0x00, 0x00, 0xa4, 0x00, 0x00, 0x00,
    'T',  0x00, 0x00, 0x00, 0x98, 0x00, 0x00, 0x00,
    0x88, 0x00, 0x00, 0x00
};

#else // QT_NO_DEBUG

QT_PLUGIN_METADATA_SECTION
static const unsigned char qt_pluginMetaData[] = {
    'Q', 'T', 'M', 'E', 'T', 'A', 'D', 'A', 'T', 'A', ' ', ' ',
    'q',  'b',  'j',  's',  0x01, 0x00, 0x00, 0x00,
    0xd4, 0x00, 0x00, 0x00, 0x0b, 0x00, 0x00, 0x00,
    0xc0, 0x00, 0x00, 0x00, 0x1b, 0x03, 0x00, 0x00,
    0x03, 0x00, 'I',  'I',  'D',  0x00, 0x00, 0x00,
    ':',  0x00, 'o',  'r',  'g',  '.',  'q',  't', 
    '-',  'p',  'r',  'o',  'j',  'e',  'c',  't', 
    '.',  'Q',  't',  '.',  'Q',  'D',  'e',  's', 
    'i',  'g',  'n',  'e',  'r',  'C',  'u',  's', 
    't',  'o',  'm',  'W',  'i',  'd',  'g',  'e', 
    't',  'C',  'o',  'l',  'l',  'e',  'c',  't', 
    'i',  'o',  'n',  'I',  'n',  't',  'e',  'r', 
    'f',  'a',  'c',  'e',  0x95, 0x0c, 0x00, 0x00,
    0x08, 0x00, 'M',  'e',  't',  'a',  'D',  'a', 
    't',  'a',  0x00, 0x00, 0x0c, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x1b, 0x10, 0x00, 0x00, 0x09, 0x00, 'c',  'l', 
    'a',  's',  's',  'N',  'a',  'm',  'e',  0x00,
    0x1f, 0x00, 'C',  'u',  's',  't',  'o',  'm', 
    'W',  'i',  'd',  'g',  'e',  't',  'C',  'o', 
    'l',  'l',  'e',  'c',  't',  'i',  'o',  'n', 
    'I',  'n',  't',  'e',  'r',  'f',  'a',  'c', 
    'e',  0x00, 0x00, 0x00, '1',  0x00, 0x00, 0x00,
    0x05, 0x00, 'd',  'e',  'b',  'u',  'g',  0x00,
    ':',  '!',  0xa1, 0x00, 0x07, 0x00, 'v',  'e', 
    'r',  's',  'i',  'o',  'n',  0x00, 0x00, 0x00,
    0x0c, 0x00, 0x00, 0x00, 'T',  0x00, 0x00, 0x00,
    'p',  0x00, 0x00, 0x00, 0xa4, 0x00, 0x00, 0x00,
    0xb0, 0x00, 0x00, 0x00
};
#endif // QT_NO_DEBUG

using namespace QwtDesignerPlugin;
QT_MOC_EXPORT_PLUGIN(QwtDesignerPlugin::CustomWidgetCollectionInterface, CustomWidgetCollectionInterface)

struct qt_meta_stringdata_QwtDesignerPlugin__PlotInterface_t {
    QByteArrayData data[1];
    char stringdata0[33];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__PlotInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__PlotInterface_t qt_meta_stringdata_QwtDesignerPlugin__PlotInterface = {
    {
QT_MOC_LITERAL(0, 0, 32) // "QwtDesignerPlugin::PlotInterface"

    },
    "QwtDesignerPlugin::PlotInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__PlotInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::PlotInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::PlotInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__PlotInterface.data,
      qt_meta_data_QwtDesignerPlugin__PlotInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::PlotInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::PlotInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__PlotInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::PlotInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface_t {
    QByteArrayData data[1];
    char stringdata0[39];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface_t qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface = {
    {
QT_MOC_LITERAL(0, 0, 38) // "QwtDesignerPlugin::PlotCanvas..."

    },
    "QwtDesignerPlugin::PlotCanvasInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__PlotCanvasInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::PlotCanvasInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::PlotCanvasInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface.data,
      qt_meta_data_QwtDesignerPlugin__PlotCanvasInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::PlotCanvasInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::PlotCanvasInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__PlotCanvasInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::PlotCanvasInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface_t {
    QByteArrayData data[1];
    char stringdata0[40];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface_t qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface = {
    {
QT_MOC_LITERAL(0, 0, 39) // "QwtDesignerPlugin::AnalogCloc..."

    },
    "QwtDesignerPlugin::AnalogClockInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__AnalogClockInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::AnalogClockInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::AnalogClockInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface.data,
      qt_meta_data_QwtDesignerPlugin__AnalogClockInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::AnalogClockInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::AnalogClockInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__AnalogClockInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::AnalogClockInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__CompassInterface_t {
    QByteArrayData data[1];
    char stringdata0[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__CompassInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CompassInterface_t qt_meta_stringdata_QwtDesignerPlugin__CompassInterface = {
    {
QT_MOC_LITERAL(0, 0, 35) // "QwtDesignerPlugin::CompassInt..."

    },
    "QwtDesignerPlugin::CompassInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CompassInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CompassInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CompassInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CompassInterface.data,
      qt_meta_data_QwtDesignerPlugin__CompassInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::CompassInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CompassInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CompassInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::CompassInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__CounterInterface_t {
    QByteArrayData data[1];
    char stringdata0[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__CounterInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__CounterInterface_t qt_meta_stringdata_QwtDesignerPlugin__CounterInterface = {
    {
QT_MOC_LITERAL(0, 0, 35) // "QwtDesignerPlugin::CounterInt..."

    },
    "QwtDesignerPlugin::CounterInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__CounterInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::CounterInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::CounterInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__CounterInterface.data,
      qt_meta_data_QwtDesignerPlugin__CounterInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::CounterInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::CounterInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__CounterInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::CounterInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__DialInterface_t {
    QByteArrayData data[1];
    char stringdata0[33];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__DialInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__DialInterface_t qt_meta_stringdata_QwtDesignerPlugin__DialInterface = {
    {
QT_MOC_LITERAL(0, 0, 32) // "QwtDesignerPlugin::DialInterface"

    },
    "QwtDesignerPlugin::DialInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__DialInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::DialInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::DialInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__DialInterface.data,
      qt_meta_data_QwtDesignerPlugin__DialInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::DialInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::DialInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__DialInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::DialInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__KnobInterface_t {
    QByteArrayData data[1];
    char stringdata0[33];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__KnobInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__KnobInterface_t qt_meta_stringdata_QwtDesignerPlugin__KnobInterface = {
    {
QT_MOC_LITERAL(0, 0, 32) // "QwtDesignerPlugin::KnobInterface"

    },
    "QwtDesignerPlugin::KnobInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__KnobInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::KnobInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::KnobInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__KnobInterface.data,
      qt_meta_data_QwtDesignerPlugin__KnobInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::KnobInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::KnobInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__KnobInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::KnobInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface_t {
    QByteArrayData data[1];
    char stringdata0[40];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface_t qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface = {
    {
QT_MOC_LITERAL(0, 0, 39) // "QwtDesignerPlugin::ScaleWidge..."

    },
    "QwtDesignerPlugin::ScaleWidgetInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__ScaleWidgetInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::ScaleWidgetInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::ScaleWidgetInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface.data,
      qt_meta_data_QwtDesignerPlugin__ScaleWidgetInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::ScaleWidgetInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::ScaleWidgetInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__ScaleWidgetInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::ScaleWidgetInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__SliderInterface_t {
    QByteArrayData data[1];
    char stringdata0[35];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__SliderInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__SliderInterface_t qt_meta_stringdata_QwtDesignerPlugin__SliderInterface = {
    {
QT_MOC_LITERAL(0, 0, 34) // "QwtDesignerPlugin::SliderInte..."

    },
    "QwtDesignerPlugin::SliderInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__SliderInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::SliderInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::SliderInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__SliderInterface.data,
      qt_meta_data_QwtDesignerPlugin__SliderInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::SliderInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::SliderInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__SliderInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::SliderInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface_t {
    QByteArrayData data[1];
    char stringdata0[38];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface_t qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface = {
    {
QT_MOC_LITERAL(0, 0, 37) // "QwtDesignerPlugin::TextLabelI..."

    },
    "QwtDesignerPlugin::TextLabelInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__TextLabelInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::TextLabelInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::TextLabelInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface.data,
      qt_meta_data_QwtDesignerPlugin__TextLabelInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::TextLabelInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::TextLabelInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__TextLabelInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::TextLabelInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface_t {
    QByteArrayData data[1];
    char stringdata0[35];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface_t qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface = {
    {
QT_MOC_LITERAL(0, 0, 34) // "QwtDesignerPlugin::ThermoInte..."

    },
    "QwtDesignerPlugin::ThermoInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__ThermoInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::ThermoInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::ThermoInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface.data,
      qt_meta_data_QwtDesignerPlugin__ThermoInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::ThermoInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::ThermoInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__ThermoInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::ThermoInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__WheelInterface_t {
    QByteArrayData data[1];
    char stringdata0[34];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__WheelInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__WheelInterface_t qt_meta_stringdata_QwtDesignerPlugin__WheelInterface = {
    {
QT_MOC_LITERAL(0, 0, 33) // "QwtDesignerPlugin::WheelInter..."

    },
    "QwtDesignerPlugin::WheelInterface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__WheelInterface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::WheelInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::WheelInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__WheelInterface.data,
      qt_meta_data_QwtDesignerPlugin__WheelInterface,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::WheelInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::WheelInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__WheelInterface.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "org.qt-project.QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(this);
    return CustomWidgetInterface::qt_metacast(_clname);
}

int QwtDesignerPlugin::WheelInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory_t {
    QByteArrayData data[1];
    char stringdata0[35];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory_t qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory = {
    {
QT_MOC_LITERAL(0, 0, 34) // "QwtDesignerPlugin::TaskMenuFa..."

    },
    "QwtDesignerPlugin::TaskMenuFactory"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__TaskMenuFactory[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QwtDesignerPlugin::TaskMenuFactory::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QwtDesignerPlugin::TaskMenuFactory::staticMetaObject = {
    { &QExtensionFactory::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory.data,
      qt_meta_data_QwtDesignerPlugin__TaskMenuFactory,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::TaskMenuFactory::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::TaskMenuFactory::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuFactory.stringdata0))
        return static_cast<void*>(this);
    return QExtensionFactory::qt_metacast(_clname);
}

int QwtDesignerPlugin::TaskMenuFactory::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QExtensionFactory::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension_t {
    QByteArrayData data[4];
    char stringdata0[69];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension_t qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension = {
    {
QT_MOC_LITERAL(0, 0, 36), // "QwtDesignerPlugin::TaskMenuEx..."
QT_MOC_LITERAL(1, 37, 14), // "editProperties"
QT_MOC_LITERAL(2, 52, 0), // ""
QT_MOC_LITERAL(3, 53, 15) // "applyProperties"

    },
    "QwtDesignerPlugin::TaskMenuExtension\0"
    "editProperties\0\0applyProperties"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtDesignerPlugin__TaskMenuExtension[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   24,    2, 0x08 /* Private */,
       3,    1,   25,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,

       0        // eod
};

void QwtDesignerPlugin::TaskMenuExtension::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TaskMenuExtension *_t = static_cast<TaskMenuExtension *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->editProperties(); break;
        case 1: _t->applyProperties((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject QwtDesignerPlugin::TaskMenuExtension::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension.data,
      qt_meta_data_QwtDesignerPlugin__TaskMenuExtension,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtDesignerPlugin::TaskMenuExtension::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtDesignerPlugin::TaskMenuExtension::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtDesignerPlugin__TaskMenuExtension.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QDesignerTaskMenuExtension"))
        return static_cast< QDesignerTaskMenuExtension*>(this);
    if (!strcmp(_clname, "org.qt-project.Qt.Designer.TaskMenu"))
        return static_cast< QDesignerTaskMenuExtension*>(this);
    return QObject::qt_metacast(_clname);
}

int QwtDesignerPlugin::TaskMenuExtension::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
