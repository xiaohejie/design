/****************************************************************************
** Meta object code from reading C++ file 'qwt_wheel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../src/3rdParty/qwt/src/qwt_wheel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qwt_wheel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QwtWheel_t {
    QByteArrayData data[29];
    char stringdata0[312];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QwtWheel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QwtWheel_t qt_meta_stringdata_QwtWheel = {
    {
QT_MOC_LITERAL(0, 0, 8), // "QwtWheel"
QT_MOC_LITERAL(1, 9, 12), // "valueChanged"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 5), // "value"
QT_MOC_LITERAL(4, 29, 12), // "wheelPressed"
QT_MOC_LITERAL(5, 42, 13), // "wheelReleased"
QT_MOC_LITERAL(6, 56, 10), // "wheelMoved"
QT_MOC_LITERAL(7, 67, 8), // "setValue"
QT_MOC_LITERAL(8, 76, 13), // "setTotalAngle"
QT_MOC_LITERAL(9, 90, 12), // "setViewAngle"
QT_MOC_LITERAL(10, 103, 7), // "setMass"
QT_MOC_LITERAL(11, 111, 11), // "orientation"
QT_MOC_LITERAL(12, 123, 15), // "Qt::Orientation"
QT_MOC_LITERAL(13, 139, 7), // "minimum"
QT_MOC_LITERAL(14, 147, 7), // "maximum"
QT_MOC_LITERAL(15, 155, 10), // "singleStep"
QT_MOC_LITERAL(16, 166, 13), // "pageStepCount"
QT_MOC_LITERAL(17, 180, 13), // "stepAlignment"
QT_MOC_LITERAL(18, 194, 8), // "tracking"
QT_MOC_LITERAL(19, 203, 8), // "wrapping"
QT_MOC_LITERAL(20, 212, 8), // "inverted"
QT_MOC_LITERAL(21, 221, 4), // "mass"
QT_MOC_LITERAL(22, 226, 14), // "updateInterval"
QT_MOC_LITERAL(23, 241, 10), // "totalAngle"
QT_MOC_LITERAL(24, 252, 9), // "viewAngle"
QT_MOC_LITERAL(25, 262, 9), // "tickCount"
QT_MOC_LITERAL(26, 272, 10), // "wheelWidth"
QT_MOC_LITERAL(27, 283, 11), // "borderWidth"
QT_MOC_LITERAL(28, 295, 16) // "wheelBorderWidth"

    },
    "QwtWheel\0valueChanged\0\0value\0wheelPressed\0"
    "wheelReleased\0wheelMoved\0setValue\0"
    "setTotalAngle\0setViewAngle\0setMass\0"
    "orientation\0Qt::Orientation\0minimum\0"
    "maximum\0singleStep\0pageStepCount\0"
    "stepAlignment\0tracking\0wrapping\0"
    "inverted\0mass\0updateInterval\0totalAngle\0"
    "viewAngle\0tickCount\0wheelWidth\0"
    "borderWidth\0wheelBorderWidth"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QwtWheel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
      18,   74, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06 /* Public */,
       4,    0,   57,    2, 0x06 /* Public */,
       5,    0,   58,    2, 0x06 /* Public */,
       6,    1,   59,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,   62,    2, 0x0a /* Public */,
       8,    1,   65,    2, 0x0a /* Public */,
       9,    1,   68,    2, 0x0a /* Public */,
      10,    1,   71,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::Double,    2,
    QMetaType::Void, QMetaType::Double,    2,
    QMetaType::Void, QMetaType::Double,    2,
    QMetaType::Void, QMetaType::Double,    2,

 // properties: name, type, flags
      11, 0x80000000 | 12, 0x0009510b,
       3, QMetaType::Double, 0x00095103,
      13, QMetaType::Double, 0x00095103,
      14, QMetaType::Double, 0x00095103,
      15, QMetaType::Double, 0x00095103,
      16, QMetaType::Int, 0x00095103,
      17, QMetaType::Bool, 0x00095103,
      18, QMetaType::Bool, 0x00095103,
      19, QMetaType::Bool, 0x00095103,
      20, QMetaType::Bool, 0x00095103,
      21, QMetaType::Double, 0x00095103,
      22, QMetaType::Int, 0x00095103,
      23, QMetaType::Double, 0x00095103,
      24, QMetaType::Double, 0x00095103,
      25, QMetaType::Int, 0x00095103,
      26, QMetaType::Int, 0x00095103,
      27, QMetaType::Int, 0x00095103,
      28, QMetaType::Int, 0x00095103,

       0        // eod
};

void QwtWheel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QwtWheel *_t = static_cast<QwtWheel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: _t->wheelPressed(); break;
        case 2: _t->wheelReleased(); break;
        case 3: _t->wheelMoved((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->setValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 5: _t->setTotalAngle((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 6: _t->setViewAngle((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: _t->setMass((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (QwtWheel::*_t)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QwtWheel::valueChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (QwtWheel::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QwtWheel::wheelPressed)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (QwtWheel::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QwtWheel::wheelReleased)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (QwtWheel::*_t)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QwtWheel::wheelMoved)) {
                *result = 3;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QwtWheel *_t = static_cast<QwtWheel *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< Qt::Orientation*>(_v) = _t->orientation(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->value(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->minimum(); break;
        case 3: *reinterpret_cast< double*>(_v) = _t->maximum(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->singleStep(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->pageStepCount(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->stepAlignment(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->isTracking(); break;
        case 8: *reinterpret_cast< bool*>(_v) = _t->wrapping(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->isInverted(); break;
        case 10: *reinterpret_cast< double*>(_v) = _t->mass(); break;
        case 11: *reinterpret_cast< int*>(_v) = _t->updateInterval(); break;
        case 12: *reinterpret_cast< double*>(_v) = _t->totalAngle(); break;
        case 13: *reinterpret_cast< double*>(_v) = _t->viewAngle(); break;
        case 14: *reinterpret_cast< int*>(_v) = _t->tickCount(); break;
        case 15: *reinterpret_cast< int*>(_v) = _t->wheelWidth(); break;
        case 16: *reinterpret_cast< int*>(_v) = _t->borderWidth(); break;
        case 17: *reinterpret_cast< int*>(_v) = _t->wheelBorderWidth(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QwtWheel *_t = static_cast<QwtWheel *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setOrientation(*reinterpret_cast< Qt::Orientation*>(_v)); break;
        case 1: _t->setValue(*reinterpret_cast< double*>(_v)); break;
        case 2: _t->setMinimum(*reinterpret_cast< double*>(_v)); break;
        case 3: _t->setMaximum(*reinterpret_cast< double*>(_v)); break;
        case 4: _t->setSingleStep(*reinterpret_cast< double*>(_v)); break;
        case 5: _t->setPageStepCount(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setStepAlignment(*reinterpret_cast< bool*>(_v)); break;
        case 7: _t->setTracking(*reinterpret_cast< bool*>(_v)); break;
        case 8: _t->setWrapping(*reinterpret_cast< bool*>(_v)); break;
        case 9: _t->setInverted(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setMass(*reinterpret_cast< double*>(_v)); break;
        case 11: _t->setUpdateInterval(*reinterpret_cast< int*>(_v)); break;
        case 12: _t->setTotalAngle(*reinterpret_cast< double*>(_v)); break;
        case 13: _t->setViewAngle(*reinterpret_cast< double*>(_v)); break;
        case 14: _t->setTickCount(*reinterpret_cast< int*>(_v)); break;
        case 15: _t->setWheelWidth(*reinterpret_cast< int*>(_v)); break;
        case 16: _t->setBorderWidth(*reinterpret_cast< int*>(_v)); break;
        case 17: _t->setWheelBorderWidth(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QwtWheel::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QwtWheel.data,
      qt_meta_data_QwtWheel,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QwtWheel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QwtWheel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QwtWheel.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int QwtWheel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 18;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 18;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 18;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 18;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 18;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QwtWheel::valueChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QwtWheel::wheelPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QwtWheel::wheelReleased()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QwtWheel::wheelMoved(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
