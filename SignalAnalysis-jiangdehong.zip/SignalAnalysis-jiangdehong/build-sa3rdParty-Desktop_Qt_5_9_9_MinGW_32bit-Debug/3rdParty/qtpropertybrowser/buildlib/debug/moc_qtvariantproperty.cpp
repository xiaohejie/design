/****************************************************************************
** Meta object code from reading C++ file 'qtvariantproperty.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../src/3rdParty/qtpropertybrowser/src/qtvariantproperty.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qtvariantproperty.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtVariantPropertyManager_t {
    QByteArrayData data[26];
    char stringdata0[418];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtVariantPropertyManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtVariantPropertyManager_t qt_meta_stringdata_QtVariantPropertyManager = {
    {
QT_MOC_LITERAL(0, 0, 24), // "QtVariantPropertyManager"
QT_MOC_LITERAL(1, 25, 12), // "valueChanged"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 11), // "QtProperty*"
QT_MOC_LITERAL(4, 51, 8), // "property"
QT_MOC_LITERAL(5, 60, 3), // "val"
QT_MOC_LITERAL(6, 64, 16), // "attributeChanged"
QT_MOC_LITERAL(7, 81, 9), // "attribute"
QT_MOC_LITERAL(8, 91, 8), // "setValue"
QT_MOC_LITERAL(9, 100, 12), // "setAttribute"
QT_MOC_LITERAL(10, 113, 5), // "value"
QT_MOC_LITERAL(11, 119, 16), // "slotValueChanged"
QT_MOC_LITERAL(12, 136, 16), // "slotRangeChanged"
QT_MOC_LITERAL(13, 153, 21), // "slotSingleStepChanged"
QT_MOC_LITERAL(14, 175, 19), // "slotDecimalsChanged"
QT_MOC_LITERAL(15, 195, 17), // "slotRegExpChanged"
QT_MOC_LITERAL(16, 213, 19), // "slotEchoModeChanged"
QT_MOC_LITERAL(17, 233, 21), // "slotConstraintChanged"
QT_MOC_LITERAL(18, 255, 20), // "slotEnumNamesChanged"
QT_MOC_LITERAL(19, 276, 20), // "slotEnumIconsChanged"
QT_MOC_LITERAL(20, 297, 15), // "QMap<int,QIcon>"
QT_MOC_LITERAL(21, 313, 20), // "slotFlagNamesChanged"
QT_MOC_LITERAL(22, 334, 19), // "slotReadOnlyChanged"
QT_MOC_LITERAL(23, 354, 22), // "slotTextVisibleChanged"
QT_MOC_LITERAL(24, 377, 20), // "slotPropertyInserted"
QT_MOC_LITERAL(25, 398, 19) // "slotPropertyRemoved"

    },
    "QtVariantPropertyManager\0valueChanged\0"
    "\0QtProperty*\0property\0val\0attributeChanged\0"
    "attribute\0setValue\0setAttribute\0value\0"
    "slotValueChanged\0slotRangeChanged\0"
    "slotSingleStepChanged\0slotDecimalsChanged\0"
    "slotRegExpChanged\0slotEchoModeChanged\0"
    "slotConstraintChanged\0slotEnumNamesChanged\0"
    "slotEnumIconsChanged\0QMap<int,QIcon>\0"
    "slotFlagNamesChanged\0slotReadOnlyChanged\0"
    "slotTextVisibleChanged\0slotPropertyInserted\0"
    "slotPropertyRemoved"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtVariantPropertyManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  229,    2, 0x06 /* Public */,
       6,    3,  234,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    2,  241,    2, 0x0a /* Public */,
       9,    3,  246,    2, 0x0a /* Public */,
      11,    2,  253,    2, 0x08 /* Private */,
      12,    3,  258,    2, 0x08 /* Private */,
      13,    2,  265,    2, 0x08 /* Private */,
      11,    2,  270,    2, 0x08 /* Private */,
      12,    3,  275,    2, 0x08 /* Private */,
      13,    2,  282,    2, 0x08 /* Private */,
      14,    2,  287,    2, 0x08 /* Private */,
      11,    2,  292,    2, 0x08 /* Private */,
      11,    2,  297,    2, 0x08 /* Private */,
      15,    2,  302,    2, 0x08 /* Private */,
      16,    2,  307,    2, 0x08 /* Private */,
      11,    2,  312,    2, 0x08 /* Private */,
      12,    3,  317,    2, 0x08 /* Private */,
      11,    2,  324,    2, 0x08 /* Private */,
      11,    2,  329,    2, 0x08 /* Private */,
      11,    2,  334,    2, 0x08 /* Private */,
      11,    2,  339,    2, 0x08 /* Private */,
      11,    2,  344,    2, 0x08 /* Private */,
      11,    2,  349,    2, 0x08 /* Private */,
      11,    2,  354,    2, 0x08 /* Private */,
      11,    2,  359,    2, 0x08 /* Private */,
      12,    3,  364,    2, 0x08 /* Private */,
      11,    2,  371,    2, 0x08 /* Private */,
      12,    3,  376,    2, 0x08 /* Private */,
      11,    2,  383,    2, 0x08 /* Private */,
      17,    2,  388,    2, 0x08 /* Private */,
      11,    2,  393,    2, 0x08 /* Private */,
      17,    2,  398,    2, 0x08 /* Private */,
      11,    2,  403,    2, 0x08 /* Private */,
      18,    2,  408,    2, 0x08 /* Private */,
      19,    2,  413,    2, 0x08 /* Private */,
      11,    2,  418,    2, 0x08 /* Private */,
      11,    2,  423,    2, 0x08 /* Private */,
      11,    2,  428,    2, 0x08 /* Private */,
      21,    2,  433,    2, 0x08 /* Private */,
      22,    2,  438,    2, 0x08 /* Private */,
      23,    2,  443,    2, 0x08 /* Private */,
      24,    3,  448,    2, 0x08 /* Private */,
      25,    2,  455,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::QVariant,    4,    5,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QString, QMetaType::QVariant,    4,    7,    5,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::QVariant,    4,    5,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QString, QMetaType::QVariant,    4,    7,   10,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Double,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Double, QMetaType::Double,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Double,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Bool,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QString,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QRegExp,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QDate,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QDate, QMetaType::QDate,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QTime,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QDateTime,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QKeySequence,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QChar,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QLocale,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QPoint,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QPointF,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QSize,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QSize, QMetaType::QSize,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QSizeF,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QSizeF, QMetaType::QSizeF,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QRect,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QRect,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QRectF,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QRectF,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QColor,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QStringList,    2,    2,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 20,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QSizePolicy,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QFont,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QCursor,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QStringList,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Bool,    2,    2,
    QMetaType::Void, 0x80000000 | 3, QMetaType::Bool,    2,    2,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3, 0x80000000 | 3,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    2,    2,

       0        // eod
};

void QtVariantPropertyManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QtVariantPropertyManager *_t = static_cast<QtVariantPropertyManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->valueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2]))); break;
        case 1: _t->attributeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QVariant(*)>(_a[3]))); break;
        case 2: _t->setValue((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2]))); break;
        case 3: _t->setAttribute((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QVariant(*)>(_a[3]))); break;
        case 4: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->d_func()->slotRangeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 6: _t->d_func()->slotSingleStepChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 8: _t->d_func()->slotRangeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 9: _t->d_func()->slotSingleStepChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 10: _t->d_func()->slotDecimalsChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 12: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 13: _t->d_func()->slotRegExpChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QRegExp(*)>(_a[2]))); break;
        case 14: _t->d_func()->slotEchoModeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 15: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QDate(*)>(_a[2]))); break;
        case 16: _t->d_func()->slotRangeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QDate(*)>(_a[2])),(*reinterpret_cast< const QDate(*)>(_a[3]))); break;
        case 17: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QTime(*)>(_a[2]))); break;
        case 18: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QDateTime(*)>(_a[2]))); break;
        case 19: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QKeySequence(*)>(_a[2]))); break;
        case 20: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QChar(*)>(_a[2]))); break;
        case 21: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QLocale(*)>(_a[2]))); break;
        case 22: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QPoint(*)>(_a[2]))); break;
        case 23: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QPointF(*)>(_a[2]))); break;
        case 24: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QSize(*)>(_a[2]))); break;
        case 25: _t->d_func()->slotRangeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QSize(*)>(_a[2])),(*reinterpret_cast< const QSize(*)>(_a[3]))); break;
        case 26: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QSizeF(*)>(_a[2]))); break;
        case 27: _t->d_func()->slotRangeChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QSizeF(*)>(_a[2])),(*reinterpret_cast< const QSizeF(*)>(_a[3]))); break;
        case 28: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QRect(*)>(_a[2]))); break;
        case 29: _t->d_func()->slotConstraintChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QRect(*)>(_a[2]))); break;
        case 30: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QRectF(*)>(_a[2]))); break;
        case 31: _t->d_func()->slotConstraintChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QRectF(*)>(_a[2]))); break;
        case 32: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QColor(*)>(_a[2]))); break;
        case 33: _t->d_func()->slotEnumNamesChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QStringList(*)>(_a[2]))); break;
        case 34: _t->d_func()->slotEnumIconsChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QMap<int,QIcon>(*)>(_a[2]))); break;
        case 35: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QSizePolicy(*)>(_a[2]))); break;
        case 36: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QFont(*)>(_a[2]))); break;
        case 37: _t->d_func()->slotValueChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QCursor(*)>(_a[2]))); break;
        case 38: _t->d_func()->slotFlagNamesChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< const QStringList(*)>(_a[2]))); break;
        case 39: _t->d_func()->slotReadOnlyChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 40: _t->d_func()->slotTextVisibleChanged((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 41: _t->d_func()->slotPropertyInserted((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< QtProperty*(*)>(_a[2])),(*reinterpret_cast< QtProperty*(*)>(_a[3]))); break;
        case 42: _t->d_func()->slotPropertyRemoved((*reinterpret_cast< QtProperty*(*)>(_a[1])),(*reinterpret_cast< QtProperty*(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (QtVariantPropertyManager::*_t)(QtProperty * , const QVariant & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtVariantPropertyManager::valueChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (QtVariantPropertyManager::*_t)(QtProperty * , const QString & , const QVariant & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QtVariantPropertyManager::attributeChanged)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject QtVariantPropertyManager::staticMetaObject = {
    { &QtAbstractPropertyManager::staticMetaObject, qt_meta_stringdata_QtVariantPropertyManager.data,
      qt_meta_data_QtVariantPropertyManager,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QtVariantPropertyManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtVariantPropertyManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtVariantPropertyManager.stringdata0))
        return static_cast<void*>(this);
    return QtAbstractPropertyManager::qt_metacast(_clname);
}

int QtVariantPropertyManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QtAbstractPropertyManager::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 43;
    }
    return _id;
}

// SIGNAL 0
void QtVariantPropertyManager::valueChanged(QtProperty * _t1, const QVariant & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QtVariantPropertyManager::attributeChanged(QtProperty * _t1, const QString & _t2, const QVariant & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QtVariantEditorFactory_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtVariantEditorFactory_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtVariantEditorFactory_t qt_meta_stringdata_QtVariantEditorFactory = {
    {
QT_MOC_LITERAL(0, 0, 22) // "QtVariantEditorFactory"

    },
    "QtVariantEditorFactory"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtVariantEditorFactory[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QtVariantEditorFactory::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QtVariantEditorFactory::staticMetaObject = {
    { &QtAbstractEditorFactory<QtVariantPropertyManager>::staticMetaObject, qt_meta_stringdata_QtVariantEditorFactory.data,
      qt_meta_data_QtVariantEditorFactory,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *QtVariantEditorFactory::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtVariantEditorFactory::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtVariantEditorFactory.stringdata0))
        return static_cast<void*>(this);
    return QtAbstractEditorFactory<QtVariantPropertyManager>::qt_metacast(_clname);
}

int QtVariantEditorFactory::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QtAbstractEditorFactory<QtVariantPropertyManager>::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
