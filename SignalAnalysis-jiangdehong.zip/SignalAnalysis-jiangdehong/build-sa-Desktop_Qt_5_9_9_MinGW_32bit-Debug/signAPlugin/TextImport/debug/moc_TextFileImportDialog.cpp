/****************************************************************************
** Meta object code from reading C++ file 'TextFileImportDialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../src/signAPlugin/TextImport/TextFileImportDialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TextFileImportDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TextFileImportDialog_t {
    QByteArrayData data[26];
    char stringdata0[555];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TextFileImportDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TextFileImportDialog_t qt_meta_stringdata_TextFileImportDialog = {
    {
QT_MOC_LITERAL(0, 0, 20), // "TextFileImportDialog"
QT_MOC_LITERAL(1, 21, 26), // "on_pushButton_Next_clicked"
QT_MOC_LITERAL(2, 48, 0), // ""
QT_MOC_LITERAL(3, 49, 37), // "on_spinBox_startReadLine_valu..."
QT_MOC_LITERAL(4, 87, 4), // "arg1"
QT_MOC_LITERAL(5, 92, 41), // "on_comboBox_Separator_current..."
QT_MOC_LITERAL(6, 134, 5), // "index"
QT_MOC_LITERAL(7, 140, 26), // "on_pushButton_Back_clicked"
QT_MOC_LITERAL(8, 167, 25), // "on_radioButton_1D_toggled"
QT_MOC_LITERAL(9, 193, 7), // "checked"
QT_MOC_LITERAL(10, 201, 32), // "on_spinBox_toHeader_valueChanged"
QT_MOC_LITERAL(11, 234, 31), // "on_stackedWidget_currentChanged"
QT_MOC_LITERAL(12, 266, 31), // "on_spinBox_endLine_valueChanged"
QT_MOC_LITERAL(13, 298, 37), // "on_comboBox_codec_currentInde..."
QT_MOC_LITERAL(14, 336, 36), // "on_comboBox_codec_currentText..."
QT_MOC_LITERAL(15, 373, 12), // "onHaveParser"
QT_MOC_LITERAL(16, 386, 32), // "on_radioButton_oneColumn_clicked"
QT_MOC_LITERAL(17, 419, 18), // "onTextReadComplete"
QT_MOC_LITERAL(18, 438, 4), // "text"
QT_MOC_LITERAL(19, 443, 4), // "isOK"
QT_MOC_LITERAL(20, 448, 21), // "onTextThreadDestroyed"
QT_MOC_LITERAL(21, 470, 3), // "obj"
QT_MOC_LITERAL(22, 474, 19), // "startReadTextThread"
QT_MOC_LITERAL(23, 494, 8), // "filePath"
QT_MOC_LITERAL(24, 503, 19), // "onAppendTextTimeOut"
QT_MOC_LITERAL(25, 523, 31) // "on_pushButton_DatasView_clicked"

    },
    "TextFileImportDialog\0on_pushButton_Next_clicked\0"
    "\0on_spinBox_startReadLine_valueChanged\0"
    "arg1\0on_comboBox_Separator_currentIndexChanged\0"
    "index\0on_pushButton_Back_clicked\0"
    "on_radioButton_1D_toggled\0checked\0"
    "on_spinBox_toHeader_valueChanged\0"
    "on_stackedWidget_currentChanged\0"
    "on_spinBox_endLine_valueChanged\0"
    "on_comboBox_codec_currentIndexChanged\0"
    "on_comboBox_codec_currentTextChanged\0"
    "onHaveParser\0on_radioButton_oneColumn_clicked\0"
    "onTextReadComplete\0text\0isOK\0"
    "onTextThreadDestroyed\0obj\0startReadTextThread\0"
    "filePath\0onAppendTextTimeOut\0"
    "on_pushButton_DatasView_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TextFileImportDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   99,    2, 0x08 /* Private */,
       3,    1,  100,    2, 0x08 /* Private */,
       5,    1,  103,    2, 0x08 /* Private */,
       7,    0,  106,    2, 0x08 /* Private */,
       8,    1,  107,    2, 0x08 /* Private */,
      10,    1,  110,    2, 0x08 /* Private */,
      11,    1,  113,    2, 0x08 /* Private */,
      12,    1,  116,    2, 0x08 /* Private */,
      13,    1,  119,    2, 0x08 /* Private */,
      14,    1,  122,    2, 0x08 /* Private */,
      15,    0,  125,    2, 0x08 /* Private */,
      16,    1,  126,    2, 0x08 /* Private */,
      17,    2,  129,    2, 0x08 /* Private */,
      20,    1,  134,    2, 0x08 /* Private */,
      22,    1,  137,    2, 0x08 /* Private */,
      24,    0,  140,    2, 0x08 /* Private */,
      25,    0,  141,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   18,   19,
    QMetaType::Void, QMetaType::QObjectStar,   21,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TextFileImportDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TextFileImportDialog *_t = static_cast<TextFileImportDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_Next_clicked(); break;
        case 1: _t->on_spinBox_startReadLine_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_comboBox_Separator_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_pushButton_Back_clicked(); break;
        case 4: _t->on_radioButton_1D_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->on_spinBox_toHeader_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_stackedWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_spinBox_endLine_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_comboBox_codec_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->on_comboBox_codec_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->onHaveParser(); break;
        case 11: _t->on_radioButton_oneColumn_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->onTextReadComplete((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 13: _t->onTextThreadDestroyed((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        case 14: _t->startReadTextThread((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->onAppendTextTimeOut(); break;
        case 16: _t->on_pushButton_DatasView_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject TextFileImportDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_TextFileImportDialog.data,
      qt_meta_data_TextFileImportDialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *TextFileImportDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TextFileImportDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TextFileImportDialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int TextFileImportDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
