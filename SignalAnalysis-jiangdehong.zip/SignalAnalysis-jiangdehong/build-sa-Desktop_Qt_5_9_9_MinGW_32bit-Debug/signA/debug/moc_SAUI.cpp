/****************************************************************************
** Meta object code from reading C++ file 'SAUI.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/signA/SAUI.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SAUI.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SAUI_t {
    QByteArrayData data[26];
    char stringdata0[400];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SAUI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SAUI_t qt_meta_stringdata_SAUI = {
    {
QT_MOC_LITERAL(0, 0, 4), // "SAUI"
QT_MOC_LITERAL(1, 5, 21), // "showNormalMessageInfo"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 4), // "info"
QT_MOC_LITERAL(4, 33, 8), // "interval"
QT_MOC_LITERAL(5, 42, 20), // "showErrorMessageInfo"
QT_MOC_LITERAL(6, 63, 22), // "showWarningMessageInfo"
QT_MOC_LITERAL(7, 86, 23), // "showQuestionMessageInfo"
QT_MOC_LITERAL(8, 110, 15), // "showMessageInfo"
QT_MOC_LITERAL(9, 126, 15), // "SA::MeaasgeType"
QT_MOC_LITERAL(10, 142, 11), // "messageType"
QT_MOC_LITERAL(11, 154, 21), // "showWidgetMessageInfo"
QT_MOC_LITERAL(12, 176, 8), // "QWidget*"
QT_MOC_LITERAL(13, 185, 6), // "widget"
QT_MOC_LITERAL(14, 192, 22), // "showElapesdMessageInfo"
QT_MOC_LITERAL(15, 215, 4), // "type"
QT_MOC_LITERAL(16, 220, 21), // "hideProgressStatusBar"
QT_MOC_LITERAL(17, 242, 21), // "showProgressStatusBar"
QT_MOC_LITERAL(18, 264, 27), // "setProgressStatusBarVisible"
QT_MOC_LITERAL(19, 292, 6), // "isShow"
QT_MOC_LITERAL(20, 299, 27), // "setProgressStatusBarPresent"
QT_MOC_LITERAL(21, 327, 7), // "present"
QT_MOC_LITERAL(22, 335, 24), // "setProgressStatusBarText"
QT_MOC_LITERAL(23, 360, 4), // "text"
QT_MOC_LITERAL(24, 365, 20), // "getProgressStatusBar"
QT_MOC_LITERAL(25, 386, 13) // "QProgressBar*"

    },
    "SAUI\0showNormalMessageInfo\0\0info\0"
    "interval\0showErrorMessageInfo\0"
    "showWarningMessageInfo\0showQuestionMessageInfo\0"
    "showMessageInfo\0SA::MeaasgeType\0"
    "messageType\0showWidgetMessageInfo\0"
    "QWidget*\0widget\0showElapesdMessageInfo\0"
    "type\0hideProgressStatusBar\0"
    "showProgressStatusBar\0setProgressStatusBarVisible\0"
    "isShow\0setProgressStatusBarPresent\0"
    "present\0setProgressStatusBarText\0text\0"
    "getProgressStatusBar\0QProgressBar*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SAUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,  109,    2, 0x0a /* Public */,
       1,    1,  114,    2, 0x2a /* Public | MethodCloned */,
       5,    2,  117,    2, 0x0a /* Public */,
       5,    1,  122,    2, 0x2a /* Public | MethodCloned */,
       6,    2,  125,    2, 0x0a /* Public */,
       6,    1,  130,    2, 0x2a /* Public | MethodCloned */,
       7,    2,  133,    2, 0x0a /* Public */,
       7,    1,  138,    2, 0x2a /* Public | MethodCloned */,
       8,    2,  141,    2, 0x0a /* Public */,
      11,    4,  146,    2, 0x0a /* Public */,
      14,    3,  155,    2, 0x0a /* Public */,
      14,    2,  162,    2, 0x2a /* Public | MethodCloned */,
      14,    1,  167,    2, 0x2a /* Public | MethodCloned */,
      16,    0,  170,    2, 0x0a /* Public */,
      17,    0,  171,    2, 0x0a /* Public */,
      18,    1,  172,    2, 0x0a /* Public */,
      20,    1,  175,    2, 0x0a /* Public */,
      22,    1,  178,    2, 0x0a /* Public */,
      24,    0,  181,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 9,    3,   10,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 12, 0x80000000 | 9, QMetaType::Int,    3,   13,   10,    4,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 9, QMetaType::Int,    3,   15,    4,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 9,    3,   15,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::QString,   23,
    0x80000000 | 25,

       0        // eod
};

void SAUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SAUI *_t = static_cast<SAUI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showNormalMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->showNormalMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->showErrorMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->showErrorMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->showWarningMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->showWarningMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->showQuestionMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->showQuestionMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->showMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[2]))); break;
        case 9: _t->showWidgetMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< QWidget*(*)>(_a[2])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 10: _t->showElapesdMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 11: _t->showElapesdMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[2]))); break;
        case 12: _t->showElapesdMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->hideProgressStatusBar(); break;
        case 14: _t->showProgressStatusBar(); break;
        case 15: _t->setProgressStatusBarVisible((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->setProgressStatusBarPresent((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->setProgressStatusBarText((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: { QProgressBar* _r = _t->getProgressStatusBar();
            if (_a[0]) *reinterpret_cast< QProgressBar**>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

const QMetaObject SAUI::staticMetaObject = {
    { &SAUIInterface::staticMetaObject, qt_meta_stringdata_SAUI.data,
      qt_meta_data_SAUI,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SAUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SAUI::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SAUI.stringdata0))
        return static_cast<void*>(this);
    return SAUIInterface::qt_metacast(_clname);
}

int SAUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SAUIInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
