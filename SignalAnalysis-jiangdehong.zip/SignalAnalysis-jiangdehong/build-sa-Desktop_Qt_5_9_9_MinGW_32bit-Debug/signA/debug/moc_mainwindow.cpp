/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/signA/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[159];
    char stringdata0[3823];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 12), // "cleanCapture"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 17), // "startCleanProject"
QT_MOC_LITERAL(4, 43, 14), // "cleanedProject"
QT_MOC_LITERAL(5, 58, 20), // "subWindowHaveCreated"
QT_MOC_LITERAL(6, 79, 15), // "SAMdiSubWindow*"
QT_MOC_LITERAL(7, 95, 3), // "wnd"
QT_MOC_LITERAL(8, 99, 17), // "selectDataChanged"
QT_MOC_LITERAL(9, 117, 16), // "SAAbstractDatas*"
QT_MOC_LITERAL(10, 134, 7), // "dataPtr"
QT_MOC_LITERAL(11, 142, 15), // "ShutDownCapture"
QT_MOC_LITERAL(12, 158, 21), // "showNormalMessageInfo"
QT_MOC_LITERAL(13, 180, 4), // "info"
QT_MOC_LITERAL(14, 185, 8), // "interval"
QT_MOC_LITERAL(15, 194, 20), // "showErrorMessageInfo"
QT_MOC_LITERAL(16, 215, 22), // "showWarningMessageInfo"
QT_MOC_LITERAL(17, 238, 23), // "showQuestionMessageInfo"
QT_MOC_LITERAL(18, 262, 15), // "showMessageInfo"
QT_MOC_LITERAL(19, 278, 15), // "SA::MeaasgeType"
QT_MOC_LITERAL(20, 294, 11), // "messageType"
QT_MOC_LITERAL(21, 306, 21), // "showWidgetMessageInfo"
QT_MOC_LITERAL(22, 328, 8), // "QWidget*"
QT_MOC_LITERAL(23, 337, 6), // "widget"
QT_MOC_LITERAL(24, 344, 22), // "showElapesdMessageInfo"
QT_MOC_LITERAL(25, 367, 4), // "type"
QT_MOC_LITERAL(26, 372, 21), // "hideProgressStatusBar"
QT_MOC_LITERAL(27, 394, 21), // "showProgressStatusBar"
QT_MOC_LITERAL(28, 416, 27), // "setProgressStatusBarVisible"
QT_MOC_LITERAL(29, 444, 6), // "isShow"
QT_MOC_LITERAL(30, 451, 27), // "setProgressStatusBarPresent"
QT_MOC_LITERAL(31, 479, 7), // "present"
QT_MOC_LITERAL(32, 487, 24), // "setProgressStatusBarText"
QT_MOC_LITERAL(33, 512, 4), // "text"
QT_MOC_LITERAL(34, 517, 36), // "setTableRibbonContextCategory..."
QT_MOC_LITERAL(35, 554, 2), // "on"
QT_MOC_LITERAL(36, 557, 16), // "mainInitHardware"
QT_MOC_LITERAL(37, 574, 14), // "m_bhwconnected"
QT_MOC_LITERAL(38, 589, 21), // "mainCloseSaveResource"
QT_MOC_LITERAL(39, 611, 22), // "mainCloseRedisResource"
QT_MOC_LITERAL(40, 634, 19), // "closeSaveDataThread"
QT_MOC_LITERAL(41, 654, 21), // "closePlaybackResource"
QT_MOC_LITERAL(42, 676, 27), // "closeSinglePlaybackRescouce"
QT_MOC_LITERAL(43, 704, 18), // "clickActionProdcut"
QT_MOC_LITERAL(44, 723, 20), // "OnButtonStartCapture"
QT_MOC_LITERAL(45, 744, 19), // "OnButtonStopCapture"
QT_MOC_LITERAL(46, 764, 22), // "OnBUttonSuspendCapture"
QT_MOC_LITERAL(47, 787, 21), // "OnButtonStartPlayBack"
QT_MOC_LITERAL(48, 809, 20), // "OnButtonStopPlayBack"
QT_MOC_LITERAL(49, 830, 20), // "OnButtonKillPlayBack"
QT_MOC_LITERAL(50, 851, 16), // "OnButtonAnalysis"
QT_MOC_LITERAL(51, 868, 14), // "onFocusChanged"
QT_MOC_LITERAL(52, 883, 3), // "old"
QT_MOC_LITERAL(53, 887, 3), // "now"
QT_MOC_LITERAL(54, 891, 29), // "onTreeViewValueManagerClicked"
QT_MOC_LITERAL(55, 921, 5), // "index"
QT_MOC_LITERAL(56, 927, 35), // "onTreeViewValueManagerDoubleC..."
QT_MOC_LITERAL(57, 963, 48), // "onTreeViewValueManagerCustomC..."
QT_MOC_LITERAL(58, 1012, 3), // "pos"
QT_MOC_LITERAL(59, 1016, 28), // "onActionValueRenameTriggered"
QT_MOC_LITERAL(60, 1045, 21), // "onActionOpenTriggered"
QT_MOC_LITERAL(61, 1067, 27), // "onActionNewProjectTriggered"
QT_MOC_LITERAL(62, 1095, 21), // "onActionSaveTriggered"
QT_MOC_LITERAL(63, 1117, 23), // "onActionSaveAsTriggered"
QT_MOC_LITERAL(64, 1141, 29), // "onActionClearProjectTriggered"
QT_MOC_LITERAL(65, 1171, 34), // "onActionValueCreateWizardTrig..."
QT_MOC_LITERAL(66, 1206, 40), // "onActionValueCreateDoubleVect..."
QT_MOC_LITERAL(67, 1247, 39), // "onActionValueCreatePointVecto..."
QT_MOC_LITERAL(68, 1287, 40), // "onActionValueCreateVariantTab..."
QT_MOC_LITERAL(69, 1328, 27), // "onMdiAreaSubWindowActivated"
QT_MOC_LITERAL(70, 1356, 14), // "QMdiSubWindow*"
QT_MOC_LITERAL(71, 1371, 4), // "arg1"
QT_MOC_LITERAL(72, 1376, 17), // "onSubWindowClosed"
QT_MOC_LITERAL(73, 1394, 38), // "onActionViewValueInCurrentTab..."
QT_MOC_LITERAL(74, 1433, 44), // "onActionViewValueAppendInCurr..."
QT_MOC_LITERAL(75, 1478, 34), // "onActionViewValueInNewTabTrig..."
QT_MOC_LITERAL(76, 1513, 28), // "onActionValueDeleteTriggered"
QT_MOC_LITERAL(77, 1542, 16), // "onActionOpenData"
QT_MOC_LITERAL(78, 1559, 17), // "onRedisConnection"
QT_MOC_LITERAL(79, 1577, 20), // "onHardWareConnection"
QT_MOC_LITERAL(80, 1598, 29), // "onActionAddLineChartTriggered"
QT_MOC_LITERAL(81, 1628, 28), // "onActionAddBarChartTriggered"
QT_MOC_LITERAL(82, 1657, 34), // "onActionAddHistogramChartTrig..."
QT_MOC_LITERAL(83, 1692, 32), // "onActionAddScatterChartTriggered"
QT_MOC_LITERAL(84, 1725, 28), // "onActionAddBoxChartTriggered"
QT_MOC_LITERAL(85, 1754, 33), // "onActionAddIntervalChartTrigg..."
QT_MOC_LITERAL(86, 1788, 32), // "onActionStartRectSelectTriggered"
QT_MOC_LITERAL(87, 1821, 1), // "b"
QT_MOC_LITERAL(88, 1823, 35), // "onActionStartEllipseSelectTri..."
QT_MOC_LITERAL(89, 1859, 35), // "onActionStartPolygonSelectTri..."
QT_MOC_LITERAL(90, 1895, 45), // "onActionChartClearAllSelectie..."
QT_MOC_LITERAL(91, 1941, 43), // "onActionChartActiveSingleSele..."
QT_MOC_LITERAL(92, 1985, 47), // "onActionChartActiveAdditional..."
QT_MOC_LITERAL(93, 2033, 48), // "onActionChartActiveSubtractio..."
QT_MOC_LITERAL(94, 2082, 49), // "onActionChartActiveIntersecti..."
QT_MOC_LITERAL(95, 2132, 32), // "onActionChartSelectionRegionMove"
QT_MOC_LITERAL(96, 2165, 38), // "onActionChartMoveDataInSelect..."
QT_MOC_LITERAL(97, 2204, 34), // "onActionChartEnablePickerTrig..."
QT_MOC_LITERAL(98, 2239, 5), // "check"
QT_MOC_LITERAL(99, 2245, 34), // "onActionChartEnablePannerTrig..."
QT_MOC_LITERAL(100, 2280, 32), // "onActionChartEnableZoomTriggered"
QT_MOC_LITERAL(101, 2313, 35), // "onActionSetChartZoomToBaseTri..."
QT_MOC_LITERAL(102, 2349, 28), // "onActionChartZoomInTriggered"
QT_MOC_LITERAL(103, 2378, 29), // "onActionChartZoomOutTriggered"
QT_MOC_LITERAL(104, 2408, 27), // "onActionChartZoomInBestView"
QT_MOC_LITERAL(105, 2436, 31), // "onActionChartZoomResetTriggered"
QT_MOC_LITERAL(106, 2468, 28), // "onActionYDataPickerTriggered"
QT_MOC_LITERAL(107, 2497, 29), // "onActionXYDataPickerTriggered"
QT_MOC_LITERAL(108, 2527, 25), // "onActionShowGridTriggered"
QT_MOC_LITERAL(109, 2553, 26), // "onActionShowHGridTriggered"
QT_MOC_LITERAL(110, 2580, 26), // "onActionShowVGridTriggered"
QT_MOC_LITERAL(111, 2607, 33), // "onActionShowCrowdedHGridTrigg..."
QT_MOC_LITERAL(112, 2641, 33), // "onActionShowCrowdedVGridTrigg..."
QT_MOC_LITERAL(113, 2675, 27), // "onActionShowLegendTriggered"
QT_MOC_LITERAL(114, 2703, 32), // "onActionShowLegendPanelTriggered"
QT_MOC_LITERAL(115, 2736, 42), // "onActionFigureEditSubPlotGeom..."
QT_MOC_LITERAL(116, 2779, 38), // "onActionChartRemoveInRangData..."
QT_MOC_LITERAL(117, 2818, 32), // "onActionPickCurveToDataTriggered"
QT_MOC_LITERAL(118, 2851, 21), // "onActionColorMapTable"
QT_MOC_LITERAL(119, 2873, 22), // "onActionAboutTriggered"
QT_MOC_LITERAL(120, 2896, 21), // "onActionUndoTriggered"
QT_MOC_LITERAL(121, 2918, 21), // "onActionRedoTriggered"
QT_MOC_LITERAL(122, 2940, 34), // "onActionSetDefalutDockPosTrig..."
QT_MOC_LITERAL(123, 2975, 24), // "onActionTabModeTriggered"
QT_MOC_LITERAL(124, 3000, 27), // "onActionWindowModeTriggered"
QT_MOC_LITERAL(125, 3028, 30), // "onActionWindowCascadeTriggered"
QT_MOC_LITERAL(126, 3059, 27), // "onActionWindowTileTriggered"
QT_MOC_LITERAL(127, 3087, 32), // "onActionDataFeatureDockTriggered"
QT_MOC_LITERAL(128, 3120, 34), // "onActionSubWindowListDockTrig..."
QT_MOC_LITERAL(129, 3155, 33), // "onActionValueManagerDockTrigg..."
QT_MOC_LITERAL(130, 3189, 29), // "onActionLayerOutDockTriggered"
QT_MOC_LITERAL(131, 3219, 32), // "onActionValueViewerDockTriggered"
QT_MOC_LITERAL(132, 3252, 29), // "onActionFigureViewerTriggered"
QT_MOC_LITERAL(133, 3282, 32), // "onActionMessageInfoDockTriggered"
QT_MOC_LITERAL(134, 3315, 30), // "onActionFigureSetDockTriggered"
QT_MOC_LITERAL(135, 3346, 31), // "onActionProjectSettingTriggered"
QT_MOC_LITERAL(136, 3378, 19), // "onActionSkinChanged"
QT_MOC_LITERAL(137, 3398, 8), // "QAction*"
QT_MOC_LITERAL(138, 3407, 3), // "act"
QT_MOC_LITERAL(139, 3411, 33), // "onActionGroupRibbonStyleTrigg..."
QT_MOC_LITERAL(140, 3445, 26), // "onLayoutWidgetItemSelected"
QT_MOC_LITERAL(141, 3472, 12), // "QwtPlotItem*"
QT_MOC_LITERAL(142, 3485, 4), // "item"
QT_MOC_LITERAL(143, 3490, 27), // "onLayoutWidgetSelectedChart"
QT_MOC_LITERAL(144, 3518, 10), // "SAChart2D*"
QT_MOC_LITERAL(145, 3529, 5), // "chart"
QT_MOC_LITERAL(146, 3535, 32), // "onLayoutWidgetItemVisibleChanged"
QT_MOC_LITERAL(147, 3568, 30), // "onLayoutWidgetItemColorChanged"
QT_MOC_LITERAL(148, 3599, 3), // "clr"
QT_MOC_LITERAL(149, 3603, 30), // "onLayoutWidgetItemTitleChanged"
QT_MOC_LITERAL(150, 3634, 5), // "title"
QT_MOC_LITERAL(151, 3640, 25), // "onLayoutWidgetItemRemoved"
QT_MOC_LITERAL(152, 3666, 19), // "onChartTitleChanged"
QT_MOC_LITERAL(153, 3686, 4), // "plot"
QT_MOC_LITERAL(154, 3691, 26), // "subwindowMouseRightClicked"
QT_MOC_LITERAL(155, 3718, 49), // "onActionSelectCurrentCursorTo..."
QT_MOC_LITERAL(156, 3768, 13), // "onDataRemoved"
QT_MOC_LITERAL(157, 3782, 23), // "QList<SAAbstractDatas*>"
QT_MOC_LITERAL(158, 3806, 16) // "dataBeDeletedPtr"

    },
    "MainWindow\0cleanCapture\0\0startCleanProject\0"
    "cleanedProject\0subWindowHaveCreated\0"
    "SAMdiSubWindow*\0wnd\0selectDataChanged\0"
    "SAAbstractDatas*\0dataPtr\0ShutDownCapture\0"
    "showNormalMessageInfo\0info\0interval\0"
    "showErrorMessageInfo\0showWarningMessageInfo\0"
    "showQuestionMessageInfo\0showMessageInfo\0"
    "SA::MeaasgeType\0messageType\0"
    "showWidgetMessageInfo\0QWidget*\0widget\0"
    "showElapesdMessageInfo\0type\0"
    "hideProgressStatusBar\0showProgressStatusBar\0"
    "setProgressStatusBarVisible\0isShow\0"
    "setProgressStatusBarPresent\0present\0"
    "setProgressStatusBarText\0text\0"
    "setTableRibbonContextCategoryVisible\0"
    "on\0mainInitHardware\0m_bhwconnected\0"
    "mainCloseSaveResource\0mainCloseRedisResource\0"
    "closeSaveDataThread\0closePlaybackResource\0"
    "closeSinglePlaybackRescouce\0"
    "clickActionProdcut\0OnButtonStartCapture\0"
    "OnButtonStopCapture\0OnBUttonSuspendCapture\0"
    "OnButtonStartPlayBack\0OnButtonStopPlayBack\0"
    "OnButtonKillPlayBack\0OnButtonAnalysis\0"
    "onFocusChanged\0old\0now\0"
    "onTreeViewValueManagerClicked\0index\0"
    "onTreeViewValueManagerDoubleClicked\0"
    "onTreeViewValueManagerCustomContextMenuRequested\0"
    "pos\0onActionValueRenameTriggered\0"
    "onActionOpenTriggered\0onActionNewProjectTriggered\0"
    "onActionSaveTriggered\0onActionSaveAsTriggered\0"
    "onActionClearProjectTriggered\0"
    "onActionValueCreateWizardTriggered\0"
    "onActionValueCreateDoubleVectorTriggered\0"
    "onActionValueCreatePointVectorTriggered\0"
    "onActionValueCreateVariantTableTriggered\0"
    "onMdiAreaSubWindowActivated\0QMdiSubWindow*\0"
    "arg1\0onSubWindowClosed\0"
    "onActionViewValueInCurrentTabTriggered\0"
    "onActionViewValueAppendInCurrentTabTriggered\0"
    "onActionViewValueInNewTabTriggered\0"
    "onActionValueDeleteTriggered\0"
    "onActionOpenData\0onRedisConnection\0"
    "onHardWareConnection\0onActionAddLineChartTriggered\0"
    "onActionAddBarChartTriggered\0"
    "onActionAddHistogramChartTriggered\0"
    "onActionAddScatterChartTriggered\0"
    "onActionAddBoxChartTriggered\0"
    "onActionAddIntervalChartTriggered\0"
    "onActionStartRectSelectTriggered\0b\0"
    "onActionStartEllipseSelectTriggered\0"
    "onActionStartPolygonSelectTriggered\0"
    "onActionChartClearAllSelectiedRegionTriggered\0"
    "onActionChartActiveSingleSelectionTriggered\0"
    "onActionChartActiveAdditionalSelectionTriggered\0"
    "onActionChartActiveSubtractionSelectionTriggered\0"
    "onActionChartActiveIntersectionSelectionTriggered\0"
    "onActionChartSelectionRegionMove\0"
    "onActionChartMoveDataInSelectionRegion\0"
    "onActionChartEnablePickerTriggered\0"
    "check\0onActionChartEnablePannerTriggered\0"
    "onActionChartEnableZoomTriggered\0"
    "onActionSetChartZoomToBaseTriggered\0"
    "onActionChartZoomInTriggered\0"
    "onActionChartZoomOutTriggered\0"
    "onActionChartZoomInBestView\0"
    "onActionChartZoomResetTriggered\0"
    "onActionYDataPickerTriggered\0"
    "onActionXYDataPickerTriggered\0"
    "onActionShowGridTriggered\0"
    "onActionShowHGridTriggered\0"
    "onActionShowVGridTriggered\0"
    "onActionShowCrowdedHGridTriggered\0"
    "onActionShowCrowdedVGridTriggered\0"
    "onActionShowLegendTriggered\0"
    "onActionShowLegendPanelTriggered\0"
    "onActionFigureEditSubPlotGeometryTriggered\0"
    "onActionChartRemoveInRangDataTriggered\0"
    "onActionPickCurveToDataTriggered\0"
    "onActionColorMapTable\0onActionAboutTriggered\0"
    "onActionUndoTriggered\0onActionRedoTriggered\0"
    "onActionSetDefalutDockPosTriggered\0"
    "onActionTabModeTriggered\0"
    "onActionWindowModeTriggered\0"
    "onActionWindowCascadeTriggered\0"
    "onActionWindowTileTriggered\0"
    "onActionDataFeatureDockTriggered\0"
    "onActionSubWindowListDockTriggered\0"
    "onActionValueManagerDockTriggered\0"
    "onActionLayerOutDockTriggered\0"
    "onActionValueViewerDockTriggered\0"
    "onActionFigureViewerTriggered\0"
    "onActionMessageInfoDockTriggered\0"
    "onActionFigureSetDockTriggered\0"
    "onActionProjectSettingTriggered\0"
    "onActionSkinChanged\0QAction*\0act\0"
    "onActionGroupRibbonStyleTriggered\0"
    "onLayoutWidgetItemSelected\0QwtPlotItem*\0"
    "item\0onLayoutWidgetSelectedChart\0"
    "SAChart2D*\0chart\0onLayoutWidgetItemVisibleChanged\0"
    "onLayoutWidgetItemColorChanged\0clr\0"
    "onLayoutWidgetItemTitleChanged\0title\0"
    "onLayoutWidgetItemRemoved\0onChartTitleChanged\0"
    "plot\0subwindowMouseRightClicked\0"
    "onActionSelectCurrentCursorToActiveChartTriggered\0"
    "onDataRemoved\0QList<SAAbstractDatas*>\0"
    "dataBeDeletedPtr"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
     129,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  659,    2, 0x06 /* Public */,
       3,    0,  660,    2, 0x06 /* Public */,
       4,    0,  661,    2, 0x06 /* Public */,
       5,    1,  662,    2, 0x06 /* Public */,
       8,    1,  665,    2, 0x06 /* Public */,
      11,    0,  668,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    2,  669,    2, 0x0a /* Public */,
      12,    1,  674,    2, 0x2a /* Public | MethodCloned */,
      15,    2,  677,    2, 0x0a /* Public */,
      15,    1,  682,    2, 0x2a /* Public | MethodCloned */,
      16,    2,  685,    2, 0x0a /* Public */,
      16,    1,  690,    2, 0x2a /* Public | MethodCloned */,
      17,    2,  693,    2, 0x0a /* Public */,
      17,    1,  698,    2, 0x2a /* Public | MethodCloned */,
      18,    2,  701,    2, 0x0a /* Public */,
      21,    4,  706,    2, 0x0a /* Public */,
      24,    3,  715,    2, 0x0a /* Public */,
      24,    2,  722,    2, 0x2a /* Public | MethodCloned */,
      24,    1,  727,    2, 0x2a /* Public | MethodCloned */,
      26,    0,  730,    2, 0x0a /* Public */,
      27,    0,  731,    2, 0x0a /* Public */,
      28,    1,  732,    2, 0x0a /* Public */,
      30,    1,  735,    2, 0x0a /* Public */,
      32,    1,  738,    2, 0x0a /* Public */,
      34,    1,  741,    2, 0x0a /* Public */,
      34,    0,  744,    2, 0x2a /* Public | MethodCloned */,
      36,    1,  745,    2, 0x0a /* Public */,
      38,    0,  748,    2, 0x0a /* Public */,
      39,    0,  749,    2, 0x0a /* Public */,
      40,    0,  750,    2, 0x0a /* Public */,
      41,    0,  751,    2, 0x0a /* Public */,
      42,    0,  752,    2, 0x0a /* Public */,
      43,    0,  753,    2, 0x0a /* Public */,
      44,    0,  754,    2, 0x08 /* Private */,
      45,    0,  755,    2, 0x08 /* Private */,
      46,    0,  756,    2, 0x08 /* Private */,
      47,    0,  757,    2, 0x08 /* Private */,
      48,    0,  758,    2, 0x08 /* Private */,
      49,    0,  759,    2, 0x08 /* Private */,
      50,    0,  760,    2, 0x08 /* Private */,
      51,    2,  761,    2, 0x08 /* Private */,
      54,    1,  766,    2, 0x08 /* Private */,
      56,    1,  769,    2, 0x08 /* Private */,
      57,    1,  772,    2, 0x08 /* Private */,
      59,    0,  775,    2, 0x08 /* Private */,
      60,    0,  776,    2, 0x08 /* Private */,
      61,    0,  777,    2, 0x08 /* Private */,
      62,    0,  778,    2, 0x08 /* Private */,
      63,    0,  779,    2, 0x08 /* Private */,
      64,    0,  780,    2, 0x08 /* Private */,
      65,    0,  781,    2, 0x08 /* Private */,
      66,    0,  782,    2, 0x08 /* Private */,
      67,    0,  783,    2, 0x08 /* Private */,
      68,    0,  784,    2, 0x08 /* Private */,
      69,    1,  785,    2, 0x08 /* Private */,
      72,    1,  788,    2, 0x08 /* Private */,
      73,    0,  791,    2, 0x08 /* Private */,
      74,    0,  792,    2, 0x08 /* Private */,
      75,    0,  793,    2, 0x08 /* Private */,
      76,    0,  794,    2, 0x08 /* Private */,
      77,    0,  795,    2, 0x08 /* Private */,
      78,    0,  796,    2, 0x08 /* Private */,
      79,    0,  797,    2, 0x08 /* Private */,
      80,    0,  798,    2, 0x08 /* Private */,
      81,    0,  799,    2, 0x08 /* Private */,
      82,    0,  800,    2, 0x08 /* Private */,
      83,    0,  801,    2, 0x08 /* Private */,
      84,    0,  802,    2, 0x08 /* Private */,
      85,    0,  803,    2, 0x08 /* Private */,
      86,    1,  804,    2, 0x08 /* Private */,
      88,    1,  807,    2, 0x08 /* Private */,
      89,    1,  810,    2, 0x08 /* Private */,
      90,    1,  813,    2, 0x08 /* Private */,
      91,    1,  816,    2, 0x08 /* Private */,
      92,    1,  819,    2, 0x08 /* Private */,
      93,    1,  822,    2, 0x08 /* Private */,
      94,    1,  825,    2, 0x08 /* Private */,
      95,    1,  828,    2, 0x08 /* Private */,
      96,    1,  831,    2, 0x08 /* Private */,
      97,    1,  834,    2, 0x08 /* Private */,
      99,    1,  837,    2, 0x08 /* Private */,
     100,    1,  840,    2, 0x08 /* Private */,
     101,    1,  843,    2, 0x08 /* Private */,
     102,    1,  846,    2, 0x08 /* Private */,
     103,    1,  849,    2, 0x08 /* Private */,
     104,    1,  852,    2, 0x08 /* Private */,
     105,    1,  855,    2, 0x08 /* Private */,
     106,    1,  858,    2, 0x08 /* Private */,
     107,    1,  861,    2, 0x08 /* Private */,
     108,    1,  864,    2, 0x08 /* Private */,
     109,    1,  867,    2, 0x08 /* Private */,
     110,    1,  870,    2, 0x08 /* Private */,
     111,    1,  873,    2, 0x08 /* Private */,
     112,    1,  876,    2, 0x08 /* Private */,
     113,    1,  879,    2, 0x08 /* Private */,
     114,    1,  882,    2, 0x08 /* Private */,
     115,    1,  885,    2, 0x08 /* Private */,
     116,    0,  888,    2, 0x08 /* Private */,
     117,    0,  889,    2, 0x08 /* Private */,
     118,    0,  890,    2, 0x08 /* Private */,
     119,    0,  891,    2, 0x08 /* Private */,
     120,    0,  892,    2, 0x08 /* Private */,
     121,    0,  893,    2, 0x08 /* Private */,
     122,    0,  894,    2, 0x08 /* Private */,
     123,    1,  895,    2, 0x08 /* Private */,
     124,    1,  898,    2, 0x08 /* Private */,
     125,    1,  901,    2, 0x08 /* Private */,
     126,    1,  904,    2, 0x08 /* Private */,
     127,    1,  907,    2, 0x08 /* Private */,
     128,    1,  910,    2, 0x08 /* Private */,
     129,    1,  913,    2, 0x08 /* Private */,
     130,    1,  916,    2, 0x08 /* Private */,
     131,    1,  919,    2, 0x08 /* Private */,
     132,    1,  922,    2, 0x08 /* Private */,
     133,    1,  925,    2, 0x08 /* Private */,
     134,    1,  928,    2, 0x08 /* Private */,
     135,    0,  931,    2, 0x08 /* Private */,
     136,    1,  932,    2, 0x08 /* Private */,
     139,    1,  935,    2, 0x08 /* Private */,
     140,    1,  938,    2, 0x08 /* Private */,
     143,    1,  941,    2, 0x08 /* Private */,
     146,    2,  944,    2, 0x08 /* Private */,
     147,    2,  949,    2, 0x08 /* Private */,
     149,    2,  954,    2, 0x08 /* Private */,
     151,    2,  959,    2, 0x08 /* Private */,
     152,    2,  964,    2, 0x08 /* Private */,
     154,    1,  969,    2, 0x08 /* Private */,
     155,    1,  972,    2, 0x08 /* Private */,
     156,    1,  975,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   13,   14,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   13,   14,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   13,   14,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   13,   14,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 19,   13,   20,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 22, 0x80000000 | 19, QMetaType::Int,   13,   23,   20,   14,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 19, QMetaType::Int,   13,   25,   14,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 19,   13,   25,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::QString,   33,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   37,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 22, 0x80000000 | 22,   52,   53,
    QMetaType::Void, QMetaType::QModelIndex,   55,
    QMetaType::Void, QMetaType::QModelIndex,   55,
    QMetaType::Void, QMetaType::QPoint,   58,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 70,   71,
    QMetaType::Void, 0x80000000 | 70,   71,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   87,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   98,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 137,  138,
    QMetaType::Void, 0x80000000 | 137,  138,
    QMetaType::Void, 0x80000000 | 141,  142,
    QMetaType::Void, 0x80000000 | 144,  145,
    QMetaType::Void, 0x80000000 | 141, QMetaType::Bool,  142,   35,
    QMetaType::Void, 0x80000000 | 141, QMetaType::QColor,  142,  148,
    QMetaType::Void, 0x80000000 | 141, QMetaType::QString,  142,  150,
    QMetaType::Void, 0x80000000 | 144, 0x80000000 | 141,  145,  142,
    QMetaType::Void, 0x80000000 | 144, QMetaType::QString,  153,  150,
    QMetaType::Void, QMetaType::QPoint,   58,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, 0x80000000 | 157,  158,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->cleanCapture(); break;
        case 1: _t->startCleanProject(); break;
        case 2: _t->cleanedProject(); break;
        case 3: _t->subWindowHaveCreated((*reinterpret_cast< SAMdiSubWindow*(*)>(_a[1]))); break;
        case 4: _t->selectDataChanged((*reinterpret_cast< SAAbstractDatas*(*)>(_a[1]))); break;
        case 5: _t->ShutDownCapture(); break;
        case 6: _t->showNormalMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->showNormalMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->showErrorMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 9: _t->showErrorMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->showWarningMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: _t->showWarningMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->showQuestionMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 13: _t->showQuestionMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->showMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[2]))); break;
        case 15: _t->showWidgetMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< QWidget*(*)>(_a[2])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 16: _t->showElapesdMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 17: _t->showElapesdMessageInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< SA::MeaasgeType(*)>(_a[2]))); break;
        case 18: _t->showElapesdMessageInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->hideProgressStatusBar(); break;
        case 20: _t->showProgressStatusBar(); break;
        case 21: _t->setProgressStatusBarVisible((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->setProgressStatusBarPresent((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->setProgressStatusBarText((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 24: _t->setTableRibbonContextCategoryVisible((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->setTableRibbonContextCategoryVisible(); break;
        case 26: _t->mainInitHardware((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->mainCloseSaveResource(); break;
        case 28: _t->mainCloseRedisResource(); break;
        case 29: _t->closeSaveDataThread(); break;
        case 30: _t->closePlaybackResource(); break;
        case 31: _t->closeSinglePlaybackRescouce(); break;
        case 32: _t->clickActionProdcut(); break;
        case 33: _t->OnButtonStartCapture(); break;
        case 34: _t->OnButtonStopCapture(); break;
        case 35: _t->OnBUttonSuspendCapture(); break;
        case 36: _t->OnButtonStartPlayBack(); break;
        case 37: _t->OnButtonStopPlayBack(); break;
        case 38: _t->OnButtonKillPlayBack(); break;
        case 39: _t->OnButtonAnalysis(); break;
        case 40: _t->onFocusChanged((*reinterpret_cast< QWidget*(*)>(_a[1])),(*reinterpret_cast< QWidget*(*)>(_a[2]))); break;
        case 41: _t->onTreeViewValueManagerClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 42: _t->onTreeViewValueManagerDoubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 43: _t->onTreeViewValueManagerCustomContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 44: _t->onActionValueRenameTriggered(); break;
        case 45: _t->onActionOpenTriggered(); break;
        case 46: _t->onActionNewProjectTriggered(); break;
        case 47: _t->onActionSaveTriggered(); break;
        case 48: _t->onActionSaveAsTriggered(); break;
        case 49: _t->onActionClearProjectTriggered(); break;
        case 50: _t->onActionValueCreateWizardTriggered(); break;
        case 51: _t->onActionValueCreateDoubleVectorTriggered(); break;
        case 52: _t->onActionValueCreatePointVectorTriggered(); break;
        case 53: _t->onActionValueCreateVariantTableTriggered(); break;
        case 54: _t->onMdiAreaSubWindowActivated((*reinterpret_cast< QMdiSubWindow*(*)>(_a[1]))); break;
        case 55: _t->onSubWindowClosed((*reinterpret_cast< QMdiSubWindow*(*)>(_a[1]))); break;
        case 56: _t->onActionViewValueInCurrentTabTriggered(); break;
        case 57: _t->onActionViewValueAppendInCurrentTabTriggered(); break;
        case 58: _t->onActionViewValueInNewTabTriggered(); break;
        case 59: _t->onActionValueDeleteTriggered(); break;
        case 60: _t->onActionOpenData(); break;
        case 61: _t->onRedisConnection(); break;
        case 62: _t->onHardWareConnection(); break;
        case 63: _t->onActionAddLineChartTriggered(); break;
        case 64: _t->onActionAddBarChartTriggered(); break;
        case 65: _t->onActionAddHistogramChartTriggered(); break;
        case 66: _t->onActionAddScatterChartTriggered(); break;
        case 67: _t->onActionAddBoxChartTriggered(); break;
        case 68: _t->onActionAddIntervalChartTriggered(); break;
        case 69: _t->onActionStartRectSelectTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 70: _t->onActionStartEllipseSelectTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 71: _t->onActionStartPolygonSelectTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 72: _t->onActionChartClearAllSelectiedRegionTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 73: _t->onActionChartActiveSingleSelectionTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 74: _t->onActionChartActiveAdditionalSelectionTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 75: _t->onActionChartActiveSubtractionSelectionTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 76: _t->onActionChartActiveIntersectionSelectionTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 77: _t->onActionChartSelectionRegionMove((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 78: _t->onActionChartMoveDataInSelectionRegion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 79: _t->onActionChartEnablePickerTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 80: _t->onActionChartEnablePannerTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 81: _t->onActionChartEnableZoomTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 82: _t->onActionSetChartZoomToBaseTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 83: _t->onActionChartZoomInTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 84: _t->onActionChartZoomOutTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 85: _t->onActionChartZoomInBestView((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 86: _t->onActionChartZoomResetTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 87: _t->onActionYDataPickerTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 88: _t->onActionXYDataPickerTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 89: _t->onActionShowGridTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 90: _t->onActionShowHGridTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 91: _t->onActionShowVGridTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 92: _t->onActionShowCrowdedHGridTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 93: _t->onActionShowCrowdedVGridTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 94: _t->onActionShowLegendTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 95: _t->onActionShowLegendPanelTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 96: _t->onActionFigureEditSubPlotGeometryTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 97: _t->onActionChartRemoveInRangDataTriggered(); break;
        case 98: _t->onActionPickCurveToDataTriggered(); break;
        case 99: _t->onActionColorMapTable(); break;
        case 100: _t->onActionAboutTriggered(); break;
        case 101: _t->onActionUndoTriggered(); break;
        case 102: _t->onActionRedoTriggered(); break;
        case 103: _t->onActionSetDefalutDockPosTriggered(); break;
        case 104: _t->onActionTabModeTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 105: _t->onActionWindowModeTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 106: _t->onActionWindowCascadeTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 107: _t->onActionWindowTileTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 108: _t->onActionDataFeatureDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 109: _t->onActionSubWindowListDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 110: _t->onActionValueManagerDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 111: _t->onActionLayerOutDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 112: _t->onActionValueViewerDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 113: _t->onActionFigureViewerTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 114: _t->onActionMessageInfoDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 115: _t->onActionFigureSetDockTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 116: _t->onActionProjectSettingTriggered(); break;
        case 117: _t->onActionSkinChanged((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 118: _t->onActionGroupRibbonStyleTriggered((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 119: _t->onLayoutWidgetItemSelected((*reinterpret_cast< QwtPlotItem*(*)>(_a[1]))); break;
        case 120: _t->onLayoutWidgetSelectedChart((*reinterpret_cast< SAChart2D*(*)>(_a[1]))); break;
        case 121: _t->onLayoutWidgetItemVisibleChanged((*reinterpret_cast< QwtPlotItem*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 122: _t->onLayoutWidgetItemColorChanged((*reinterpret_cast< QwtPlotItem*(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2]))); break;
        case 123: _t->onLayoutWidgetItemTitleChanged((*reinterpret_cast< QwtPlotItem*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 124: _t->onLayoutWidgetItemRemoved((*reinterpret_cast< SAChart2D*(*)>(_a[1])),(*reinterpret_cast< QwtPlotItem*(*)>(_a[2]))); break;
        case 125: _t->onChartTitleChanged((*reinterpret_cast< SAChart2D*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 126: _t->subwindowMouseRightClicked((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 127: _t->onActionSelectCurrentCursorToActiveChartTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 128: _t->onDataRemoved((*reinterpret_cast< const QList<SAAbstractDatas*>(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< SAMdiSubWindow* >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        case 40:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        case 54:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMdiSubWindow* >(); break;
            }
            break;
        case 55:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMdiSubWindow* >(); break;
            }
            break;
        case 117:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        case 118:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        case 119:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QwtPlotItem* >(); break;
            }
            break;
        case 121:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QwtPlotItem* >(); break;
            }
            break;
        case 122:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QwtPlotItem* >(); break;
            }
            break;
        case 123:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QwtPlotItem* >(); break;
            }
            break;
        case 124:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QwtPlotItem* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::cleanCapture)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::startCleanProject)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::cleanedProject)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(SAMdiSubWindow * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::subWindowHaveCreated)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(SAAbstractDatas * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::selectDataChanged)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::ShutDownCapture)) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &SARibbonMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return SARibbonMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SARibbonMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 129)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 129;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 129)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 129;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::cleanCapture()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void MainWindow::startCleanProject()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void MainWindow::cleanedProject()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void MainWindow::subWindowHaveCreated(SAMdiSubWindow * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MainWindow::selectDataChanged(SAAbstractDatas * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::ShutDownCapture()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
