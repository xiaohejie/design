/****************************************************************************
** Meta object code from reading C++ file 'SARibbonBar.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../../src/SARibbonBar/SARibbon/src/SARibbonBar/SARibbonBar.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SARibbonBar.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SARibbonBar_t {
    QByteArrayData data[31];
    char stringdata0[489];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SARibbonBar_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SARibbonBar_t qt_meta_stringdata_SARibbonBar = {
    {
QT_MOC_LITERAL(0, 0, 11), // "SARibbonBar"
QT_MOC_LITERAL(1, 12, 24), // "applicationButtonClicked"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 23), // "currentRibbonTabChanged"
QT_MOC_LITERAL(4, 62, 5), // "index"
QT_MOC_LITERAL(5, 68, 20), // "onWindowTitleChanged"
QT_MOC_LITERAL(6, 89, 5), // "title"
QT_MOC_LITERAL(7, 95, 28), // "onCategoryWindowTitleChanged"
QT_MOC_LITERAL(8, 124, 18), // "onStackWidgetHided"
QT_MOC_LITERAL(9, 143, 25), // "onCurrentRibbonTabChanged"
QT_MOC_LITERAL(10, 169, 25), // "onCurrentRibbonTabClicked"
QT_MOC_LITERAL(11, 195, 31), // "onCurrentRibbonTabDoubleClicked"
QT_MOC_LITERAL(12, 227, 27), // "onContextsCategoryPageAdded"
QT_MOC_LITERAL(13, 255, 17), // "SARibbonCategory*"
QT_MOC_LITERAL(14, 273, 8), // "category"
QT_MOC_LITERAL(15, 282, 10), // "onTabMoved"
QT_MOC_LITERAL(16, 293, 4), // "from"
QT_MOC_LITERAL(17, 298, 2), // "to"
QT_MOC_LITERAL(18, 301, 15), // "addCategoryPage"
QT_MOC_LITERAL(19, 317, 8), // "QWidget*"
QT_MOC_LITERAL(20, 326, 11), // "ribbonStyle"
QT_MOC_LITERAL(21, 338, 11), // "RibbonStyle"
QT_MOC_LITERAL(22, 350, 11), // "minimumMode"
QT_MOC_LITERAL(23, 362, 17), // "minimumModeButton"
QT_MOC_LITERAL(24, 380, 11), // "OfficeStyle"
QT_MOC_LITERAL(25, 392, 12), // "WpsLiteStyle"
QT_MOC_LITERAL(26, 405, 17), // "OfficeStyleTwoRow"
QT_MOC_LITERAL(27, 423, 18), // "WpsLiteStyleTwoRow"
QT_MOC_LITERAL(28, 442, 11), // "RibbonState"
QT_MOC_LITERAL(29, 454, 17), // "MinimumRibbonMode"
QT_MOC_LITERAL(30, 472, 16) // "NormalRibbonMode"

    },
    "SARibbonBar\0applicationButtonClicked\0"
    "\0currentRibbonTabChanged\0index\0"
    "onWindowTitleChanged\0title\0"
    "onCategoryWindowTitleChanged\0"
    "onStackWidgetHided\0onCurrentRibbonTabChanged\0"
    "onCurrentRibbonTabClicked\0"
    "onCurrentRibbonTabDoubleClicked\0"
    "onContextsCategoryPageAdded\0"
    "SARibbonCategory*\0category\0onTabMoved\0"
    "from\0to\0addCategoryPage\0QWidget*\0"
    "ribbonStyle\0RibbonStyle\0minimumMode\0"
    "minimumModeButton\0OfficeStyle\0"
    "WpsLiteStyle\0OfficeStyleTwoRow\0"
    "WpsLiteStyleTwoRow\0RibbonState\0"
    "MinimumRibbonMode\0NormalRibbonMode"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SARibbonBar[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       3,  100, // properties
       2,  109, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x06 /* Public */,
       3,    1,   70,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   73,    2, 0x09 /* Protected */,
       7,    1,   76,    2, 0x09 /* Protected */,
       8,    0,   79,    2, 0x09 /* Protected */,
       9,    1,   80,    2, 0x09 /* Protected */,
      10,    1,   83,    2, 0x09 /* Protected */,
      11,    1,   86,    2, 0x09 /* Protected */,
      12,    1,   89,    2, 0x09 /* Protected */,
      15,    2,   92,    2, 0x09 /* Protected */,

 // methods: name, argc, parameters, tag, flags
      18,    1,   97,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   16,   17,

 // methods: parameters
    QMetaType::Void, 0x80000000 | 19,   14,

 // properties: name, type, flags
      20, 0x80000000 | 21, 0x0009510b,
      22, QMetaType::Bool, 0x00095103,
      23, QMetaType::Bool, 0x00095003,

 // enums: name, flags, count, data
      21, 0x0,    4,  117,
      28, 0x0,    2,  125,

 // enum data: key, value
      24, uint(SARibbonBar::OfficeStyle),
      25, uint(SARibbonBar::WpsLiteStyle),
      26, uint(SARibbonBar::OfficeStyleTwoRow),
      27, uint(SARibbonBar::WpsLiteStyleTwoRow),
      29, uint(SARibbonBar::MinimumRibbonMode),
      30, uint(SARibbonBar::NormalRibbonMode),

       0        // eod
};

void SARibbonBar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SARibbonBar *_t = static_cast<SARibbonBar *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->applicationButtonClicked(); break;
        case 1: _t->currentRibbonTabChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->onWindowTitleChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->onCategoryWindowTitleChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->onStackWidgetHided(); break;
        case 5: _t->onCurrentRibbonTabChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->onCurrentRibbonTabClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->onCurrentRibbonTabDoubleClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->onContextsCategoryPageAdded((*reinterpret_cast< SARibbonCategory*(*)>(_a[1]))); break;
        case 9: _t->onTabMoved((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 10: _t->addCategoryPage((*reinterpret_cast< QWidget*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< SARibbonCategory* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (SARibbonBar::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SARibbonBar::applicationButtonClicked)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (SARibbonBar::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SARibbonBar::currentRibbonTabChanged)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        SARibbonBar *_t = static_cast<SARibbonBar *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< RibbonStyle*>(_v) = _t->currentRibbonStyle(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->isMinimumMode(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->haveShowMinimumModeButton(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        SARibbonBar *_t = static_cast<SARibbonBar *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setRibbonStyle(*reinterpret_cast< RibbonStyle*>(_v)); break;
        case 1: _t->setMinimumMode(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->showMinimumModeButton(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject SARibbonBar::staticMetaObject = {
    { &QMenuBar::staticMetaObject, qt_meta_stringdata_SARibbonBar.data,
      qt_meta_data_SARibbonBar,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SARibbonBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SARibbonBar::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SARibbonBar.stringdata0))
        return static_cast<void*>(this);
    return QMenuBar::qt_metacast(_clname);
}

int SARibbonBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMenuBar::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void SARibbonBar::applicationButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void SARibbonBar::currentRibbonTabChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
