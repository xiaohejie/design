from torchvision import transforms, utils
from skimage import io, transform



def main():
    pass
    # scale = Rescale(256)
    # scale(sample) # 直接调用就好了

if __name__ == '__main__':
    main()