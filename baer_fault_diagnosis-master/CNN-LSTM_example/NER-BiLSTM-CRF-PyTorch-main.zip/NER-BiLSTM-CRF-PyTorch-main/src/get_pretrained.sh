wget https://apache-mxnet.s3.cn-north-1.amazonaws.com.cn/gluon/embeddings/glove/glove.6B.zip
mv glove.6B.zip data/
unzip data/glove.6B.zip -d data/