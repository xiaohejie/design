#ifndef DEBUGONOROFF_H
#define DEBUGONOROFF_H

//#define __DEBUG__

#endif // DEBUGONOROFF_H
