﻿#include"global.h"
//网络Tcp连接设置
QString Global::ipaddress="";

//用户登录信息
QString Global::username=""; //初始化
QString Global::type = "";

//数据库配置
QString Global::sqlIp = "127.0.0.1"; //本地使用127.0.0.1
QString Global::sqlUserName = "root"; //数据库用户名
QString Global::sqlPassWord = "123456"; //数据库连接密码
QString Global::dataBaseName = "plants_management"; //数据库名称

//地图url配置
QString Global::mapurl = "https://www.earthol.org/map-735.html";
