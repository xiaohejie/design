#ifndef GLOBAL_H
#define GLOBAL_H
#include <QWidget>



class Global{
public:
    static   QString ipaddress;

    static QString username;

    static QString type;


    static QString sqlIp;

    static QString sqlUserName;

    static QString sqlPassWord;

    static QString dataBaseName;

    static QString mapurl;
};




#endif // GLOBAL_H
