/****************************************************************************
** Meta object code from reading C++ file 'lunarcalendarwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../lunarcalendarwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lunarcalendarwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_LunarCalendarWidget_t {
    QByteArrayData data[82];
    char stringdata0[1169];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LunarCalendarWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LunarCalendarWidget_t qt_meta_stringdata_LunarCalendarWidget = {
    {
QT_MOC_LITERAL(0, 0, 19), // "LunarCalendarWidget"
QT_MOC_LITERAL(1, 20, 7), // "clicked"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 4), // "date"
QT_MOC_LITERAL(4, 34, 16), // "selectionChanged"
QT_MOC_LITERAL(5, 51, 10), // "initWidget"
QT_MOC_LITERAL(6, 62, 9), // "initStyle"
QT_MOC_LITERAL(7, 72, 8), // "initDate"
QT_MOC_LITERAL(8, 81, 11), // "yearChanged"
QT_MOC_LITERAL(9, 93, 4), // "arg1"
QT_MOC_LITERAL(10, 98, 12), // "monthChanged"
QT_MOC_LITERAL(11, 111, 26), // "LunarCalendarItem::DayType"
QT_MOC_LITERAL(12, 138, 7), // "dayType"
QT_MOC_LITERAL(13, 146, 10), // "dayChanged"
QT_MOC_LITERAL(14, 157, 11), // "dateChanged"
QT_MOC_LITERAL(15, 169, 4), // "year"
QT_MOC_LITERAL(16, 174, 5), // "month"
QT_MOC_LITERAL(17, 180, 3), // "day"
QT_MOC_LITERAL(18, 184, 16), // "showPreviousYear"
QT_MOC_LITERAL(19, 201, 12), // "showNextYear"
QT_MOC_LITERAL(20, 214, 17), // "showPreviousMonth"
QT_MOC_LITERAL(21, 232, 13), // "showNextMonth"
QT_MOC_LITERAL(22, 246, 9), // "showToday"
QT_MOC_LITERAL(23, 256, 16), // "setCalendarStyle"
QT_MOC_LITERAL(24, 273, 13), // "CalendarStyle"
QT_MOC_LITERAL(25, 287, 13), // "calendarStyle"
QT_MOC_LITERAL(26, 301, 17), // "setWeekNameFormat"
QT_MOC_LITERAL(27, 319, 14), // "WeekNameFormat"
QT_MOC_LITERAL(28, 334, 14), // "weekNameFormat"
QT_MOC_LITERAL(29, 349, 7), // "setDate"
QT_MOC_LITERAL(30, 357, 16), // "setWeekTextColor"
QT_MOC_LITERAL(31, 374, 13), // "weekTextColor"
QT_MOC_LITERAL(32, 388, 14), // "setWeekBgColor"
QT_MOC_LITERAL(33, 403, 11), // "weekBgColor"
QT_MOC_LITERAL(34, 415, 12), // "setShowLunar"
QT_MOC_LITERAL(35, 428, 9), // "showLunar"
QT_MOC_LITERAL(36, 438, 10), // "setBgImage"
QT_MOC_LITERAL(37, 449, 7), // "bgImage"
QT_MOC_LITERAL(38, 457, 13), // "setSelectType"
QT_MOC_LITERAL(39, 471, 10), // "SelectType"
QT_MOC_LITERAL(40, 482, 10), // "selectType"
QT_MOC_LITERAL(41, 493, 14), // "setBorderColor"
QT_MOC_LITERAL(42, 508, 11), // "borderColor"
QT_MOC_LITERAL(43, 520, 12), // "setWeekColor"
QT_MOC_LITERAL(44, 533, 9), // "weekColor"
QT_MOC_LITERAL(45, 543, 13), // "setSuperColor"
QT_MOC_LITERAL(46, 557, 10), // "superColor"
QT_MOC_LITERAL(47, 568, 13), // "setLunarColor"
QT_MOC_LITERAL(48, 582, 10), // "lunarColor"
QT_MOC_LITERAL(49, 593, 19), // "setCurrentTextColor"
QT_MOC_LITERAL(50, 613, 16), // "currentTextColor"
QT_MOC_LITERAL(51, 630, 17), // "setOtherTextColor"
QT_MOC_LITERAL(52, 648, 14), // "otherTextColor"
QT_MOC_LITERAL(53, 663, 18), // "setSelectTextColor"
QT_MOC_LITERAL(54, 682, 15), // "selectTextColor"
QT_MOC_LITERAL(55, 698, 17), // "setHoverTextColor"
QT_MOC_LITERAL(56, 716, 14), // "hoverTextColor"
QT_MOC_LITERAL(57, 731, 20), // "setCurrentLunarColor"
QT_MOC_LITERAL(58, 752, 17), // "currentLunarColor"
QT_MOC_LITERAL(59, 770, 18), // "setOtherLunarColor"
QT_MOC_LITERAL(60, 789, 15), // "otherLunarColor"
QT_MOC_LITERAL(61, 805, 19), // "setSelectLunarColor"
QT_MOC_LITERAL(62, 825, 16), // "selectLunarColor"
QT_MOC_LITERAL(63, 842, 18), // "setHoverLunarColor"
QT_MOC_LITERAL(64, 861, 15), // "hoverLunarColor"
QT_MOC_LITERAL(65, 877, 17), // "setCurrentBgColor"
QT_MOC_LITERAL(66, 895, 14), // "currentBgColor"
QT_MOC_LITERAL(67, 910, 15), // "setOtherBgColor"
QT_MOC_LITERAL(68, 926, 12), // "otherBgColor"
QT_MOC_LITERAL(69, 939, 16), // "setSelectBgColor"
QT_MOC_LITERAL(70, 956, 13), // "selectBgColor"
QT_MOC_LITERAL(71, 970, 15), // "setHoverBgColor"
QT_MOC_LITERAL(72, 986, 12), // "hoverBgColor"
QT_MOC_LITERAL(73, 999, 17), // "CalendarStyle_Red"
QT_MOC_LITERAL(74, 1017, 20), // "WeekNameFormat_Short"
QT_MOC_LITERAL(75, 1038, 21), // "WeekNameFormat_Normal"
QT_MOC_LITERAL(76, 1060, 19), // "WeekNameFormat_Long"
QT_MOC_LITERAL(77, 1080, 17), // "WeekNameFormat_En"
QT_MOC_LITERAL(78, 1098, 15), // "SelectType_Rect"
QT_MOC_LITERAL(79, 1114, 17), // "SelectType_Circle"
QT_MOC_LITERAL(80, 1132, 19), // "SelectType_Triangle"
QT_MOC_LITERAL(81, 1152, 16) // "SelectType_Image"

    },
    "LunarCalendarWidget\0clicked\0\0date\0"
    "selectionChanged\0initWidget\0initStyle\0"
    "initDate\0yearChanged\0arg1\0monthChanged\0"
    "LunarCalendarItem::DayType\0dayType\0"
    "dayChanged\0dateChanged\0year\0month\0day\0"
    "showPreviousYear\0showNextYear\0"
    "showPreviousMonth\0showNextMonth\0"
    "showToday\0setCalendarStyle\0CalendarStyle\0"
    "calendarStyle\0setWeekNameFormat\0"
    "WeekNameFormat\0weekNameFormat\0setDate\0"
    "setWeekTextColor\0weekTextColor\0"
    "setWeekBgColor\0weekBgColor\0setShowLunar\0"
    "showLunar\0setBgImage\0bgImage\0setSelectType\0"
    "SelectType\0selectType\0setBorderColor\0"
    "borderColor\0setWeekColor\0weekColor\0"
    "setSuperColor\0superColor\0setLunarColor\0"
    "lunarColor\0setCurrentTextColor\0"
    "currentTextColor\0setOtherTextColor\0"
    "otherTextColor\0setSelectTextColor\0"
    "selectTextColor\0setHoverTextColor\0"
    "hoverTextColor\0setCurrentLunarColor\0"
    "currentLunarColor\0setOtherLunarColor\0"
    "otherLunarColor\0setSelectLunarColor\0"
    "selectLunarColor\0setHoverLunarColor\0"
    "hoverLunarColor\0setCurrentBgColor\0"
    "currentBgColor\0setOtherBgColor\0"
    "otherBgColor\0setSelectBgColor\0"
    "selectBgColor\0setHoverBgColor\0"
    "hoverBgColor\0CalendarStyle_Red\0"
    "WeekNameFormat_Short\0WeekNameFormat_Normal\0"
    "WeekNameFormat_Long\0WeekNameFormat_En\0"
    "SelectType_Rect\0SelectType_Circle\0"
    "SelectType_Triangle\0SelectType_Image"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LunarCalendarWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      39,   14, // methods
      24,  314, // properties
       3,  386, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  209,    2, 0x06 /* Public */,
       4,    0,  212,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,  213,    2, 0x08 /* Private */,
       6,    0,  214,    2, 0x08 /* Private */,
       7,    0,  215,    2, 0x08 /* Private */,
       8,    1,  216,    2, 0x08 /* Private */,
      10,    1,  219,    2, 0x08 /* Private */,
       1,    2,  222,    2, 0x08 /* Private */,
      13,    1,  227,    2, 0x08 /* Private */,
      14,    3,  230,    2, 0x08 /* Private */,
      18,    0,  237,    2, 0x0a /* Public */,
      19,    0,  238,    2, 0x0a /* Public */,
      20,    0,  239,    2, 0x0a /* Public */,
      21,    0,  240,    2, 0x0a /* Public */,
      22,    0,  241,    2, 0x0a /* Public */,
      23,    1,  242,    2, 0x0a /* Public */,
      26,    1,  245,    2, 0x0a /* Public */,
      29,    1,  248,    2, 0x0a /* Public */,
      30,    1,  251,    2, 0x0a /* Public */,
      32,    1,  254,    2, 0x0a /* Public */,
      34,    1,  257,    2, 0x0a /* Public */,
      36,    1,  260,    2, 0x0a /* Public */,
      38,    1,  263,    2, 0x0a /* Public */,
      41,    1,  266,    2, 0x0a /* Public */,
      43,    1,  269,    2, 0x0a /* Public */,
      45,    1,  272,    2, 0x0a /* Public */,
      47,    1,  275,    2, 0x0a /* Public */,
      49,    1,  278,    2, 0x0a /* Public */,
      51,    1,  281,    2, 0x0a /* Public */,
      53,    1,  284,    2, 0x0a /* Public */,
      55,    1,  287,    2, 0x0a /* Public */,
      57,    1,  290,    2, 0x0a /* Public */,
      59,    1,  293,    2, 0x0a /* Public */,
      61,    1,  296,    2, 0x0a /* Public */,
      63,    1,  299,    2, 0x0a /* Public */,
      65,    1,  302,    2, 0x0a /* Public */,
      67,    1,  305,    2, 0x0a /* Public */,
      69,    1,  308,    2, 0x0a /* Public */,
      71,    1,  311,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QDate,    3,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QDate, 0x80000000 | 11,    3,   12,
    QMetaType::Void, QMetaType::QDate,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   15,   16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void, 0x80000000 | 27,   28,
    QMetaType::Void, QMetaType::QDate,    3,
    QMetaType::Void, QMetaType::QColor,   31,
    QMetaType::Void, QMetaType::QColor,   33,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void, 0x80000000 | 39,   40,
    QMetaType::Void, QMetaType::QColor,   42,
    QMetaType::Void, QMetaType::QColor,   44,
    QMetaType::Void, QMetaType::QColor,   46,
    QMetaType::Void, QMetaType::QColor,   48,
    QMetaType::Void, QMetaType::QColor,   50,
    QMetaType::Void, QMetaType::QColor,   52,
    QMetaType::Void, QMetaType::QColor,   54,
    QMetaType::Void, QMetaType::QColor,   56,
    QMetaType::Void, QMetaType::QColor,   58,
    QMetaType::Void, QMetaType::QColor,   60,
    QMetaType::Void, QMetaType::QColor,   62,
    QMetaType::Void, QMetaType::QColor,   64,
    QMetaType::Void, QMetaType::QColor,   66,
    QMetaType::Void, QMetaType::QColor,   68,
    QMetaType::Void, QMetaType::QColor,   70,
    QMetaType::Void, QMetaType::QColor,   72,

 // properties: name, type, flags
      25, 0x80000000 | 24, 0x0009510b,
      28, 0x80000000 | 27, 0x0009510b,
       3, QMetaType::QDate, 0x00095103,
      31, QMetaType::QColor, 0x00095103,
      33, QMetaType::QColor, 0x00095103,
      35, QMetaType::Bool, 0x00095103,
      37, QMetaType::QString, 0x00095103,
      40, 0x80000000 | 39, 0x0009510b,
      42, QMetaType::QColor, 0x00095103,
      44, QMetaType::QColor, 0x00095103,
      46, QMetaType::QColor, 0x00095103,
      48, QMetaType::QColor, 0x00095103,
      50, QMetaType::QColor, 0x00095103,
      52, QMetaType::QColor, 0x00095103,
      54, QMetaType::QColor, 0x00095103,
      56, QMetaType::QColor, 0x00095103,
      58, QMetaType::QColor, 0x00095103,
      60, QMetaType::QColor, 0x00095103,
      62, QMetaType::QColor, 0x00095103,
      64, QMetaType::QColor, 0x00095103,
      66, QMetaType::QColor, 0x00095103,
      68, QMetaType::QColor, 0x00095103,
      70, QMetaType::QColor, 0x00095103,
      72, QMetaType::QColor, 0x00095103,

 // enums: name, alias, flags, count, data
      24,   24, 0x0,    1,  401,
      27,   27, 0x0,    4,  403,
      39,   39, 0x0,    4,  411,

 // enum data: key, value
      73, uint(LunarCalendarWidget::CalendarStyle_Red),
      74, uint(LunarCalendarWidget::WeekNameFormat_Short),
      75, uint(LunarCalendarWidget::WeekNameFormat_Normal),
      76, uint(LunarCalendarWidget::WeekNameFormat_Long),
      77, uint(LunarCalendarWidget::WeekNameFormat_En),
      78, uint(LunarCalendarWidget::SelectType_Rect),
      79, uint(LunarCalendarWidget::SelectType_Circle),
      80, uint(LunarCalendarWidget::SelectType_Triangle),
      81, uint(LunarCalendarWidget::SelectType_Image),

       0        // eod
};

void LunarCalendarWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<LunarCalendarWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clicked((*reinterpret_cast< const QDate(*)>(_a[1]))); break;
        case 1: _t->selectionChanged(); break;
        case 2: _t->initWidget(); break;
        case 3: _t->initStyle(); break;
        case 4: _t->initDate(); break;
        case 5: _t->yearChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->monthChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->clicked((*reinterpret_cast< const QDate(*)>(_a[1])),(*reinterpret_cast< const LunarCalendarItem::DayType(*)>(_a[2]))); break;
        case 8: _t->dayChanged((*reinterpret_cast< const QDate(*)>(_a[1]))); break;
        case 9: _t->dateChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 10: _t->showPreviousYear(); break;
        case 11: _t->showNextYear(); break;
        case 12: _t->showPreviousMonth(); break;
        case 13: _t->showNextMonth(); break;
        case 14: _t->showToday(); break;
        case 15: _t->setCalendarStyle((*reinterpret_cast< const CalendarStyle(*)>(_a[1]))); break;
        case 16: _t->setWeekNameFormat((*reinterpret_cast< const WeekNameFormat(*)>(_a[1]))); break;
        case 17: _t->setDate((*reinterpret_cast< const QDate(*)>(_a[1]))); break;
        case 18: _t->setWeekTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 19: _t->setWeekBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 20: _t->setShowLunar((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->setBgImage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->setSelectType((*reinterpret_cast< const SelectType(*)>(_a[1]))); break;
        case 23: _t->setBorderColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 24: _t->setWeekColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 25: _t->setSuperColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 26: _t->setLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 27: _t->setCurrentTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 28: _t->setOtherTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 29: _t->setSelectTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 30: _t->setHoverTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 31: _t->setCurrentLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 32: _t->setOtherLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 33: _t->setSelectLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 34: _t->setHoverLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 35: _t->setCurrentBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 36: _t->setOtherBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 37: _t->setSelectBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 38: _t->setHoverBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (LunarCalendarWidget::*)(const QDate & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LunarCalendarWidget::clicked)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (LunarCalendarWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LunarCalendarWidget::selectionChanged)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<LunarCalendarWidget *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< CalendarStyle*>(_v) = _t->getCalendarStyle(); break;
        case 1: *reinterpret_cast< WeekNameFormat*>(_v) = _t->getWeekNameFormat(); break;
        case 2: *reinterpret_cast< QDate*>(_v) = _t->getDate(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->getWeekTextColor(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->getWeekBgColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->getShowLunar(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->getBgImage(); break;
        case 7: *reinterpret_cast< SelectType*>(_v) = _t->getSelectType(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getBorderColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getWeekColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getSuperColor(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getLunarColor(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getCurrentTextColor(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->getOtherTextColor(); break;
        case 14: *reinterpret_cast< QColor*>(_v) = _t->getSelectTextColor(); break;
        case 15: *reinterpret_cast< QColor*>(_v) = _t->getHoverTextColor(); break;
        case 16: *reinterpret_cast< QColor*>(_v) = _t->getCurrentLunarColor(); break;
        case 17: *reinterpret_cast< QColor*>(_v) = _t->getOtherLunarColor(); break;
        case 18: *reinterpret_cast< QColor*>(_v) = _t->getSelectLunarColor(); break;
        case 19: *reinterpret_cast< QColor*>(_v) = _t->getHoverLunarColor(); break;
        case 20: *reinterpret_cast< QColor*>(_v) = _t->getCurrentBgColor(); break;
        case 21: *reinterpret_cast< QColor*>(_v) = _t->getOtherBgColor(); break;
        case 22: *reinterpret_cast< QColor*>(_v) = _t->getSelectBgColor(); break;
        case 23: *reinterpret_cast< QColor*>(_v) = _t->getHoverBgColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<LunarCalendarWidget *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setCalendarStyle(*reinterpret_cast< CalendarStyle*>(_v)); break;
        case 1: _t->setWeekNameFormat(*reinterpret_cast< WeekNameFormat*>(_v)); break;
        case 2: _t->setDate(*reinterpret_cast< QDate*>(_v)); break;
        case 3: _t->setWeekTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 4: _t->setWeekBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setShowLunar(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setBgImage(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setSelectType(*reinterpret_cast< SelectType*>(_v)); break;
        case 8: _t->setBorderColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setWeekColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setSuperColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setCurrentTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 13: _t->setOtherTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 14: _t->setSelectTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 15: _t->setHoverTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 16: _t->setCurrentLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 17: _t->setOtherLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 18: _t->setSelectLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 19: _t->setHoverLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 20: _t->setCurrentBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 21: _t->setOtherBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 22: _t->setSelectBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 23: _t->setHoverBgColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject LunarCalendarWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_LunarCalendarWidget.data,
    qt_meta_data_LunarCalendarWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *LunarCalendarWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LunarCalendarWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_LunarCalendarWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int LunarCalendarWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 39)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 39;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 39)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 39;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 24;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 24;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 24;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 24;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 24;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 24;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void LunarCalendarWidget::clicked(const QDate & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LunarCalendarWidget::selectionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
