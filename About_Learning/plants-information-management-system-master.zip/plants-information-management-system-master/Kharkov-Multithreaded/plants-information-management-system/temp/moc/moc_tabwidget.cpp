/****************************************************************************
** Meta object code from reading C++ file 'tabwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../tabwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tabwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TabWidget_t {
    QByteArrayData data[38];
    char stringdata0[461];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TabWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TabWidget_t qt_meta_stringdata_TabWidget = {
    {
QT_MOC_LITERAL(0, 0, 9), // "TabWidget"
QT_MOC_LITERAL(1, 10, 11), // "linkHovered"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 4), // "link"
QT_MOC_LITERAL(4, 28, 12), // "loadProgress"
QT_MOC_LITERAL(5, 41, 8), // "progress"
QT_MOC_LITERAL(6, 50, 12), // "titleChanged"
QT_MOC_LITERAL(7, 63, 5), // "title"
QT_MOC_LITERAL(8, 69, 10), // "urlChanged"
QT_MOC_LITERAL(9, 80, 3), // "url"
QT_MOC_LITERAL(10, 84, 14), // "favIconChanged"
QT_MOC_LITERAL(11, 99, 4), // "icon"
QT_MOC_LITERAL(12, 104, 23), // "webActionEnabledChanged"
QT_MOC_LITERAL(13, 128, 25), // "QWebEnginePage::WebAction"
QT_MOC_LITERAL(14, 154, 6), // "action"
QT_MOC_LITERAL(15, 161, 7), // "enabled"
QT_MOC_LITERAL(16, 169, 17), // "devToolsRequested"
QT_MOC_LITERAL(17, 187, 15), // "QWebEnginePage*"
QT_MOC_LITERAL(18, 203, 6), // "source"
QT_MOC_LITERAL(19, 210, 16), // "findTextFinished"
QT_MOC_LITERAL(20, 227, 24), // "QWebEngineFindTextResult"
QT_MOC_LITERAL(21, 252, 6), // "result"
QT_MOC_LITERAL(22, 259, 6), // "setUrl"
QT_MOC_LITERAL(23, 266, 20), // "triggerWebPageAction"
QT_MOC_LITERAL(24, 287, 9), // "createTab"
QT_MOC_LITERAL(25, 297, 8), // "WebView*"
QT_MOC_LITERAL(26, 306, 19), // "createBackgroundTab"
QT_MOC_LITERAL(27, 326, 8), // "closeTab"
QT_MOC_LITERAL(28, 335, 5), // "index"
QT_MOC_LITERAL(29, 341, 7), // "nextTab"
QT_MOC_LITERAL(30, 349, 11), // "previousTab"
QT_MOC_LITERAL(31, 361, 20), // "handleCurrentChanged"
QT_MOC_LITERAL(32, 382, 26), // "handleContextMenuRequested"
QT_MOC_LITERAL(33, 409, 3), // "pos"
QT_MOC_LITERAL(34, 413, 8), // "cloneTab"
QT_MOC_LITERAL(35, 422, 14), // "closeOtherTabs"
QT_MOC_LITERAL(36, 437, 13), // "reloadAllTabs"
QT_MOC_LITERAL(37, 451, 9) // "reloadTab"

    },
    "TabWidget\0linkHovered\0\0link\0loadProgress\0"
    "progress\0titleChanged\0title\0urlChanged\0"
    "url\0favIconChanged\0icon\0webActionEnabledChanged\0"
    "QWebEnginePage::WebAction\0action\0"
    "enabled\0devToolsRequested\0QWebEnginePage*\0"
    "source\0findTextFinished\0"
    "QWebEngineFindTextResult\0result\0setUrl\0"
    "triggerWebPageAction\0createTab\0WebView*\0"
    "createBackgroundTab\0closeTab\0index\0"
    "nextTab\0previousTab\0handleCurrentChanged\0"
    "handleContextMenuRequested\0pos\0cloneTab\0"
    "closeOtherTabs\0reloadAllTabs\0reloadTab"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TabWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  119,    2, 0x06 /* Public */,
       4,    1,  122,    2, 0x06 /* Public */,
       6,    1,  125,    2, 0x06 /* Public */,
       8,    1,  128,    2, 0x06 /* Public */,
      10,    1,  131,    2, 0x06 /* Public */,
      12,    2,  134,    2, 0x06 /* Public */,
      16,    1,  139,    2, 0x06 /* Public */,
      19,    1,  142,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      22,    1,  145,    2, 0x0a /* Public */,
      23,    1,  148,    2, 0x0a /* Public */,
      24,    0,  151,    2, 0x0a /* Public */,
      26,    0,  152,    2, 0x0a /* Public */,
      27,    1,  153,    2, 0x0a /* Public */,
      29,    0,  156,    2, 0x0a /* Public */,
      30,    0,  157,    2, 0x0a /* Public */,
      31,    1,  158,    2, 0x08 /* Private */,
      32,    1,  161,    2, 0x08 /* Private */,
      34,    1,  164,    2, 0x08 /* Private */,
      35,    1,  167,    2, 0x08 /* Private */,
      36,    0,  170,    2, 0x08 /* Private */,
      37,    1,  171,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QUrl,    9,
    QMetaType::Void, QMetaType::QIcon,   11,
    QMetaType::Void, 0x80000000 | 13, QMetaType::Bool,   14,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, 0x80000000 | 20,   21,

 // slots: parameters
    QMetaType::Void, QMetaType::QUrl,    9,
    QMetaType::Void, 0x80000000 | 13,   14,
    0x80000000 | 25,
    0x80000000 | 25,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void, QMetaType::QPoint,   33,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   28,

       0        // eod
};

void TabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TabWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->linkHovered((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->loadProgress((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->titleChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->urlChanged((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 4: _t->favIconChanged((*reinterpret_cast< const QIcon(*)>(_a[1]))); break;
        case 5: _t->webActionEnabledChanged((*reinterpret_cast< QWebEnginePage::WebAction(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 6: _t->devToolsRequested((*reinterpret_cast< QWebEnginePage*(*)>(_a[1]))); break;
        case 7: _t->findTextFinished((*reinterpret_cast< const QWebEngineFindTextResult(*)>(_a[1]))); break;
        case 8: _t->setUrl((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 9: _t->triggerWebPageAction((*reinterpret_cast< QWebEnginePage::WebAction(*)>(_a[1]))); break;
        case 10: { WebView* _r = _t->createTab();
            if (_a[0]) *reinterpret_cast< WebView**>(_a[0]) = std::move(_r); }  break;
        case 11: { WebView* _r = _t->createBackgroundTab();
            if (_a[0]) *reinterpret_cast< WebView**>(_a[0]) = std::move(_r); }  break;
        case 12: _t->closeTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->nextTab(); break;
        case 14: _t->previousTab(); break;
        case 15: _t->handleCurrentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->handleContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 17: _t->cloneTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->closeOtherTabs((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->reloadAllTabs(); break;
        case 20: _t->reloadTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWebEnginePage* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TabWidget::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::linkHovered)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::loadProgress)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::titleChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(const QUrl & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::urlChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(const QIcon & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::favIconChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(QWebEnginePage::WebAction , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::webActionEnabledChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(QWebEnginePage * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::devToolsRequested)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(const QWebEngineFindTextResult & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::findTextFinished)) {
                *result = 7;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject TabWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QTabWidget::staticMetaObject>(),
    qt_meta_stringdata_TabWidget.data,
    qt_meta_data_TabWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TabWidget.stringdata0))
        return static_cast<void*>(this);
    return QTabWidget::qt_metacast(_clname);
}

int TabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    return _id;
}

// SIGNAL 0
void TabWidget::linkHovered(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void TabWidget::loadProgress(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void TabWidget::titleChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void TabWidget::urlChanged(const QUrl & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void TabWidget::favIconChanged(const QIcon & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void TabWidget::webActionEnabledChanged(QWebEnginePage::WebAction _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void TabWidget::devToolsRequested(QWebEnginePage * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void TabWidget::findTextFinished(const QWebEngineFindTextResult & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
