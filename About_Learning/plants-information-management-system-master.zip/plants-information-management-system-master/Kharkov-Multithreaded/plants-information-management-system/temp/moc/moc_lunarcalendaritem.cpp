/****************************************************************************
** Meta object code from reading C++ file 'lunarcalendaritem.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../lunarcalendaritem.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lunarcalendaritem.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_LunarCalendarItem_t {
    QByteArrayData data[60];
    char stringdata0[853];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LunarCalendarItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LunarCalendarItem_t qt_meta_stringdata_LunarCalendarItem = {
    {
QT_MOC_LITERAL(0, 0, 17), // "LunarCalendarItem"
QT_MOC_LITERAL(1, 18, 7), // "clicked"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 4), // "date"
QT_MOC_LITERAL(4, 32, 26), // "LunarCalendarItem::DayType"
QT_MOC_LITERAL(5, 59, 7), // "dayType"
QT_MOC_LITERAL(6, 67, 9), // "setSelect"
QT_MOC_LITERAL(7, 77, 6), // "select"
QT_MOC_LITERAL(8, 84, 12), // "setShowLunar"
QT_MOC_LITERAL(9, 97, 9), // "showLunar"
QT_MOC_LITERAL(10, 107, 10), // "setBgImage"
QT_MOC_LITERAL(11, 118, 7), // "bgImage"
QT_MOC_LITERAL(12, 126, 13), // "setSelectType"
QT_MOC_LITERAL(13, 140, 10), // "SelectType"
QT_MOC_LITERAL(14, 151, 10), // "selectType"
QT_MOC_LITERAL(15, 162, 7), // "setDate"
QT_MOC_LITERAL(16, 170, 8), // "setLunar"
QT_MOC_LITERAL(17, 179, 5), // "lunar"
QT_MOC_LITERAL(18, 185, 10), // "setDayType"
QT_MOC_LITERAL(19, 196, 7), // "DayType"
QT_MOC_LITERAL(20, 204, 14), // "setBorderColor"
QT_MOC_LITERAL(21, 219, 11), // "borderColor"
QT_MOC_LITERAL(22, 231, 12), // "setWeekColor"
QT_MOC_LITERAL(23, 244, 9), // "weekColor"
QT_MOC_LITERAL(24, 254, 13), // "setSuperColor"
QT_MOC_LITERAL(25, 268, 10), // "superColor"
QT_MOC_LITERAL(26, 279, 13), // "setLunarColor"
QT_MOC_LITERAL(27, 293, 10), // "lunarColor"
QT_MOC_LITERAL(28, 304, 19), // "setCurrentTextColor"
QT_MOC_LITERAL(29, 324, 16), // "currentTextColor"
QT_MOC_LITERAL(30, 341, 17), // "setOtherTextColor"
QT_MOC_LITERAL(31, 359, 14), // "otherTextColor"
QT_MOC_LITERAL(32, 374, 18), // "setSelectTextColor"
QT_MOC_LITERAL(33, 393, 15), // "selectTextColor"
QT_MOC_LITERAL(34, 409, 17), // "setHoverTextColor"
QT_MOC_LITERAL(35, 427, 14), // "hoverTextColor"
QT_MOC_LITERAL(36, 442, 20), // "setCurrentLunarColor"
QT_MOC_LITERAL(37, 463, 17), // "currentLunarColor"
QT_MOC_LITERAL(38, 481, 18), // "setOtherLunarColor"
QT_MOC_LITERAL(39, 500, 15), // "otherLunarColor"
QT_MOC_LITERAL(40, 516, 19), // "setSelectLunarColor"
QT_MOC_LITERAL(41, 536, 16), // "selectLunarColor"
QT_MOC_LITERAL(42, 553, 18), // "setHoverLunarColor"
QT_MOC_LITERAL(43, 572, 15), // "hoverLunarColor"
QT_MOC_LITERAL(44, 588, 17), // "setCurrentBgColor"
QT_MOC_LITERAL(45, 606, 14), // "currentBgColor"
QT_MOC_LITERAL(46, 621, 15), // "setOtherBgColor"
QT_MOC_LITERAL(47, 637, 12), // "otherBgColor"
QT_MOC_LITERAL(48, 650, 16), // "setSelectBgColor"
QT_MOC_LITERAL(49, 667, 13), // "selectBgColor"
QT_MOC_LITERAL(50, 681, 15), // "setHoverBgColor"
QT_MOC_LITERAL(51, 697, 12), // "hoverBgColor"
QT_MOC_LITERAL(52, 710, 16), // "DayType_MonthPre"
QT_MOC_LITERAL(53, 727, 17), // "DayType_MonthNext"
QT_MOC_LITERAL(54, 745, 20), // "DayType_MonthCurrent"
QT_MOC_LITERAL(55, 766, 15), // "DayType_WeekEnd"
QT_MOC_LITERAL(56, 782, 15), // "SelectType_Rect"
QT_MOC_LITERAL(57, 798, 17), // "SelectType_Circle"
QT_MOC_LITERAL(58, 816, 19), // "SelectType_Triangle"
QT_MOC_LITERAL(59, 836, 16) // "SelectType_Image"

    },
    "LunarCalendarItem\0clicked\0\0date\0"
    "LunarCalendarItem::DayType\0dayType\0"
    "setSelect\0select\0setShowLunar\0showLunar\0"
    "setBgImage\0bgImage\0setSelectType\0"
    "SelectType\0selectType\0setDate\0setLunar\0"
    "lunar\0setDayType\0DayType\0setBorderColor\0"
    "borderColor\0setWeekColor\0weekColor\0"
    "setSuperColor\0superColor\0setLunarColor\0"
    "lunarColor\0setCurrentTextColor\0"
    "currentTextColor\0setOtherTextColor\0"
    "otherTextColor\0setSelectTextColor\0"
    "selectTextColor\0setHoverTextColor\0"
    "hoverTextColor\0setCurrentLunarColor\0"
    "currentLunarColor\0setOtherLunarColor\0"
    "otherLunarColor\0setSelectLunarColor\0"
    "selectLunarColor\0setHoverLunarColor\0"
    "hoverLunarColor\0setCurrentBgColor\0"
    "currentBgColor\0setOtherBgColor\0"
    "otherBgColor\0setSelectBgColor\0"
    "selectBgColor\0setHoverBgColor\0"
    "hoverBgColor\0DayType_MonthPre\0"
    "DayType_MonthNext\0DayType_MonthCurrent\0"
    "DayType_WeekEnd\0SelectType_Rect\0"
    "SelectType_Circle\0SelectType_Triangle\0"
    "SelectType_Image"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LunarCalendarItem[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
      23,  220, // properties
       2,  289, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  139,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,  144,    2, 0x0a /* Public */,
       8,    1,  147,    2, 0x0a /* Public */,
      10,    1,  150,    2, 0x0a /* Public */,
      12,    1,  153,    2, 0x0a /* Public */,
      15,    1,  156,    2, 0x0a /* Public */,
      16,    1,  159,    2, 0x0a /* Public */,
      18,    1,  162,    2, 0x0a /* Public */,
      15,    3,  165,    2, 0x0a /* Public */,
      20,    1,  172,    2, 0x0a /* Public */,
      22,    1,  175,    2, 0x0a /* Public */,
      24,    1,  178,    2, 0x0a /* Public */,
      26,    1,  181,    2, 0x0a /* Public */,
      28,    1,  184,    2, 0x0a /* Public */,
      30,    1,  187,    2, 0x0a /* Public */,
      32,    1,  190,    2, 0x0a /* Public */,
      34,    1,  193,    2, 0x0a /* Public */,
      36,    1,  196,    2, 0x0a /* Public */,
      38,    1,  199,    2, 0x0a /* Public */,
      40,    1,  202,    2, 0x0a /* Public */,
      42,    1,  205,    2, 0x0a /* Public */,
      44,    1,  208,    2, 0x0a /* Public */,
      46,    1,  211,    2, 0x0a /* Public */,
      48,    1,  214,    2, 0x0a /* Public */,
      50,    1,  217,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QDate, 0x80000000 | 4,    3,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void, QMetaType::QDate,    3,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, 0x80000000 | 19,    5,
    QMetaType::Void, QMetaType::QDate, QMetaType::QString, 0x80000000 | 19,    3,   17,    5,
    QMetaType::Void, QMetaType::QColor,   21,
    QMetaType::Void, QMetaType::QColor,   23,
    QMetaType::Void, QMetaType::QColor,   25,
    QMetaType::Void, QMetaType::QColor,   27,
    QMetaType::Void, QMetaType::QColor,   29,
    QMetaType::Void, QMetaType::QColor,   31,
    QMetaType::Void, QMetaType::QColor,   33,
    QMetaType::Void, QMetaType::QColor,   35,
    QMetaType::Void, QMetaType::QColor,   37,
    QMetaType::Void, QMetaType::QColor,   39,
    QMetaType::Void, QMetaType::QColor,   41,
    QMetaType::Void, QMetaType::QColor,   43,
    QMetaType::Void, QMetaType::QColor,   45,
    QMetaType::Void, QMetaType::QColor,   47,
    QMetaType::Void, QMetaType::QColor,   49,
    QMetaType::Void, QMetaType::QColor,   51,

 // properties: name, type, flags
       7, QMetaType::Bool, 0x00095103,
       9, QMetaType::Bool, 0x00095103,
      11, QMetaType::QString, 0x00095103,
      14, 0x80000000 | 13, 0x0009510b,
       3, QMetaType::QDate, 0x00095103,
      17, QMetaType::QString, 0x00095103,
       5, 0x80000000 | 19, 0x0009510b,
      21, QMetaType::QColor, 0x00095103,
      23, QMetaType::QColor, 0x00095103,
      25, QMetaType::QColor, 0x00095103,
      27, QMetaType::QColor, 0x00095103,
      29, QMetaType::QColor, 0x00095103,
      31, QMetaType::QColor, 0x00095103,
      33, QMetaType::QColor, 0x00095103,
      35, QMetaType::QColor, 0x00095103,
      37, QMetaType::QColor, 0x00095103,
      39, QMetaType::QColor, 0x00095103,
      41, QMetaType::QColor, 0x00095103,
      43, QMetaType::QColor, 0x00095103,
      45, QMetaType::QColor, 0x00095103,
      47, QMetaType::QColor, 0x00095103,
      49, QMetaType::QColor, 0x00095103,
      51, QMetaType::QColor, 0x00095103,

 // enums: name, alias, flags, count, data
      19,   19, 0x0,    4,  299,
      13,   13, 0x0,    4,  307,

 // enum data: key, value
      52, uint(LunarCalendarItem::DayType_MonthPre),
      53, uint(LunarCalendarItem::DayType_MonthNext),
      54, uint(LunarCalendarItem::DayType_MonthCurrent),
      55, uint(LunarCalendarItem::DayType_WeekEnd),
      56, uint(LunarCalendarItem::SelectType_Rect),
      57, uint(LunarCalendarItem::SelectType_Circle),
      58, uint(LunarCalendarItem::SelectType_Triangle),
      59, uint(LunarCalendarItem::SelectType_Image),

       0        // eod
};

void LunarCalendarItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<LunarCalendarItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clicked((*reinterpret_cast< const QDate(*)>(_a[1])),(*reinterpret_cast< const LunarCalendarItem::DayType(*)>(_a[2]))); break;
        case 1: _t->setSelect((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setShowLunar((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setBgImage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->setSelectType((*reinterpret_cast< const SelectType(*)>(_a[1]))); break;
        case 5: _t->setDate((*reinterpret_cast< const QDate(*)>(_a[1]))); break;
        case 6: _t->setLunar((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->setDayType((*reinterpret_cast< const DayType(*)>(_a[1]))); break;
        case 8: _t->setDate((*reinterpret_cast< const QDate(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const DayType(*)>(_a[3]))); break;
        case 9: _t->setBorderColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 10: _t->setWeekColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 11: _t->setSuperColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 12: _t->setLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 13: _t->setCurrentTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 14: _t->setOtherTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 15: _t->setSelectTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 16: _t->setHoverTextColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 17: _t->setCurrentLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 18: _t->setOtherLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 19: _t->setSelectLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 20: _t->setHoverLunarColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 21: _t->setCurrentBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 22: _t->setOtherBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 23: _t->setSelectBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 24: _t->setHoverBgColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (LunarCalendarItem::*)(const QDate & , const LunarCalendarItem::DayType & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LunarCalendarItem::clicked)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<LunarCalendarItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->getSelect(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->getShowLunar(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->getBgImage(); break;
        case 3: *reinterpret_cast< SelectType*>(_v) = _t->getSelectType(); break;
        case 4: *reinterpret_cast< QDate*>(_v) = _t->getDate(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->getLunar(); break;
        case 6: *reinterpret_cast< DayType*>(_v) = _t->getDayType(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->getBorderColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getWeekColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getSuperColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getLunarColor(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->getCurrentTextColor(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getOtherTextColor(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->getSelectTextColor(); break;
        case 14: *reinterpret_cast< QColor*>(_v) = _t->getHoverTextColor(); break;
        case 15: *reinterpret_cast< QColor*>(_v) = _t->getCurrentLunarColor(); break;
        case 16: *reinterpret_cast< QColor*>(_v) = _t->getOtherLunarColor(); break;
        case 17: *reinterpret_cast< QColor*>(_v) = _t->getSelectLunarColor(); break;
        case 18: *reinterpret_cast< QColor*>(_v) = _t->getHoverLunarColor(); break;
        case 19: *reinterpret_cast< QColor*>(_v) = _t->getCurrentBgColor(); break;
        case 20: *reinterpret_cast< QColor*>(_v) = _t->getOtherBgColor(); break;
        case 21: *reinterpret_cast< QColor*>(_v) = _t->getSelectBgColor(); break;
        case 22: *reinterpret_cast< QColor*>(_v) = _t->getHoverBgColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<LunarCalendarItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSelect(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setShowLunar(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setBgImage(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setSelectType(*reinterpret_cast< SelectType*>(_v)); break;
        case 4: _t->setDate(*reinterpret_cast< QDate*>(_v)); break;
        case 5: _t->setLunar(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setDayType(*reinterpret_cast< DayType*>(_v)); break;
        case 7: _t->setBorderColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setWeekColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setSuperColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setCurrentTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setOtherTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 13: _t->setSelectTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 14: _t->setHoverTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 15: _t->setCurrentLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 16: _t->setOtherLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 17: _t->setSelectLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 18: _t->setHoverLunarColor(*reinterpret_cast< QColor*>(_v)); break;
        case 19: _t->setCurrentBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 20: _t->setOtherBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 21: _t->setSelectBgColor(*reinterpret_cast< QColor*>(_v)); break;
        case 22: _t->setHoverBgColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject LunarCalendarItem::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_LunarCalendarItem.data,
    qt_meta_data_LunarCalendarItem,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *LunarCalendarItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LunarCalendarItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_LunarCalendarItem.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int LunarCalendarItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 25;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 23;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 23;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 23;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 23;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 23;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void LunarCalendarItem::clicked(const QDate & _t1, const LunarCalendarItem::DayType & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
