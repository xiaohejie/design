#define _MSC_EXTENSIONS 
#define _INTEGRAL_MAX_BITS 64
#define _MSC_VER 1916
#define _MSC_FULL_VER 191627048
#define _MSC_BUILD 0
#define _M_AMD64 100
#define _M_X64 100
#define _WIN64 
#define _WIN32 
#define _CPPRTTI 
#define _UTF8 
#define _DEBUG 
#define _MT 
#define _DLL 
