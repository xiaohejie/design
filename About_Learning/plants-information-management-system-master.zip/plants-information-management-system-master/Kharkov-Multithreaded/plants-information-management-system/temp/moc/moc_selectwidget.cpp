/****************************************************************************
** Meta object code from reading C++ file 'selectwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../selectwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'selectwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_selectWidget_t {
    QByteArrayData data[44];
    char stringdata0[869];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_selectWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_selectWidget_t qt_meta_stringdata_selectWidget = {
    {
QT_MOC_LITERAL(0, 0, 12), // "selectWidget"
QT_MOC_LITERAL(1, 13, 16), // "on_reset_clicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 20), // "on_selectbth_clicked"
QT_MOC_LITERAL(4, 52, 18), // "on_viewtab_clicked"
QT_MOC_LITERAL(5, 71, 30), // "qrySelection_currentRowChanged"
QT_MOC_LITERAL(6, 102, 11), // "QModelIndex"
QT_MOC_LITERAL(7, 114, 7), // "current"
QT_MOC_LITERAL(8, 122, 8), // "previous"
QT_MOC_LITERAL(9, 131, 27), // "tabSelection_currentChanged"
QT_MOC_LITERAL(10, 159, 30), // "tabSelection_currentRowChanged"
QT_MOC_LITERAL(11, 190, 31), // "comboFields_currentIndexChanged"
QT_MOC_LITERAL(12, 222, 5), // "index"
QT_MOC_LITERAL(13, 228, 22), // "radioBtnAscend_clicked"
QT_MOC_LITERAL(14, 251, 23), // "radioBtnDescend_clicked"
QT_MOC_LITERAL(15, 275, 16), // "refreshTableView"
QT_MOC_LITERAL(16, 292, 22), // "on_firstrecord_clicked"
QT_MOC_LITERAL(17, 315, 21), // "on_lastrecord_clicked"
QT_MOC_LITERAL(18, 337, 18), // "on_preitem_clicked"
QT_MOC_LITERAL(19, 356, 19), // "on_nextitem_clicked"
QT_MOC_LITERAL(20, 376, 21), // "on_mohuselect_clicked"
QT_MOC_LITERAL(21, 398, 19), // "on_excelout_clicked"
QT_MOC_LITERAL(22, 418, 8), // "gethiden"
QT_MOC_LITERAL(23, 427, 27), // "QList<std::pair<bool,int> >"
QT_MOC_LITERAL(24, 455, 19), // "on_printpdf_clicked"
QT_MOC_LITERAL(25, 475, 18), // "on_checkid_clicked"
QT_MOC_LITERAL(26, 494, 20), // "on_checkname_clicked"
QT_MOC_LITERAL(27, 515, 20), // "on_checktime_clicked"
QT_MOC_LITERAL(28, 536, 21), // "on_checkthing_clicked"
QT_MOC_LITERAL(29, 558, 21), // "on_checkmoney_clicked"
QT_MOC_LITERAL(30, 580, 23), // "on_checkcompany_clicked"
QT_MOC_LITERAL(31, 604, 23), // "on_checkconnect_clicked"
QT_MOC_LITERAL(32, 628, 21), // "on_checkphone_clicked"
QT_MOC_LITERAL(33, 650, 19), // "on_checknum_clicked"
QT_MOC_LITERAL(34, 670, 24), // "on_checkoperator_clicked"
QT_MOC_LITERAL(35, 695, 23), // "on_checkfeiliao_clicked"
QT_MOC_LITERAL(36, 719, 21), // "on_checkwater_clicked"
QT_MOC_LITERAL(37, 741, 22), // "on_checkgrowth_clicked"
QT_MOC_LITERAL(38, 764, 22), // "on_checkothers_clicked"
QT_MOC_LITERAL(39, 787, 7), // "sethead"
QT_MOC_LITERAL(40, 795, 21), // "on_printpdf_2_clicked"
QT_MOC_LITERAL(41, 817, 17), // "on_shouge_clicked"
QT_MOC_LITERAL(42, 835, 18), // "on_gengxin_clicked"
QT_MOC_LITERAL(43, 854, 14) // "on_del_clicked"

    },
    "selectWidget\0on_reset_clicked\0\0"
    "on_selectbth_clicked\0on_viewtab_clicked\0"
    "qrySelection_currentRowChanged\0"
    "QModelIndex\0current\0previous\0"
    "tabSelection_currentChanged\0"
    "tabSelection_currentRowChanged\0"
    "comboFields_currentIndexChanged\0index\0"
    "radioBtnAscend_clicked\0radioBtnDescend_clicked\0"
    "refreshTableView\0on_firstrecord_clicked\0"
    "on_lastrecord_clicked\0on_preitem_clicked\0"
    "on_nextitem_clicked\0on_mohuselect_clicked\0"
    "on_excelout_clicked\0gethiden\0"
    "QList<std::pair<bool,int> >\0"
    "on_printpdf_clicked\0on_checkid_clicked\0"
    "on_checkname_clicked\0on_checktime_clicked\0"
    "on_checkthing_clicked\0on_checkmoney_clicked\0"
    "on_checkcompany_clicked\0on_checkconnect_clicked\0"
    "on_checkphone_clicked\0on_checknum_clicked\0"
    "on_checkoperator_clicked\0"
    "on_checkfeiliao_clicked\0on_checkwater_clicked\0"
    "on_checkgrowth_clicked\0on_checkothers_clicked\0"
    "sethead\0on_printpdf_2_clicked\0"
    "on_shouge_clicked\0on_gengxin_clicked\0"
    "on_del_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_selectWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  199,    2, 0x08 /* Private */,
       3,    0,  200,    2, 0x08 /* Private */,
       4,    0,  201,    2, 0x08 /* Private */,
       5,    2,  202,    2, 0x08 /* Private */,
       9,    2,  207,    2, 0x08 /* Private */,
      10,    2,  212,    2, 0x08 /* Private */,
      11,    1,  217,    2, 0x08 /* Private */,
      13,    0,  220,    2, 0x08 /* Private */,
      14,    0,  221,    2, 0x08 /* Private */,
      15,    0,  222,    2, 0x08 /* Private */,
      16,    0,  223,    2, 0x08 /* Private */,
      17,    0,  224,    2, 0x08 /* Private */,
      18,    0,  225,    2, 0x08 /* Private */,
      19,    0,  226,    2, 0x08 /* Private */,
      20,    0,  227,    2, 0x08 /* Private */,
      21,    0,  228,    2, 0x08 /* Private */,
      22,    0,  229,    2, 0x08 /* Private */,
      24,    0,  230,    2, 0x08 /* Private */,
      25,    0,  231,    2, 0x08 /* Private */,
      26,    0,  232,    2, 0x08 /* Private */,
      27,    0,  233,    2, 0x08 /* Private */,
      28,    0,  234,    2, 0x08 /* Private */,
      29,    0,  235,    2, 0x08 /* Private */,
      30,    0,  236,    2, 0x08 /* Private */,
      31,    0,  237,    2, 0x08 /* Private */,
      32,    0,  238,    2, 0x08 /* Private */,
      33,    0,  239,    2, 0x08 /* Private */,
      34,    0,  240,    2, 0x08 /* Private */,
      35,    0,  241,    2, 0x08 /* Private */,
      36,    0,  242,    2, 0x08 /* Private */,
      37,    0,  243,    2, 0x08 /* Private */,
      38,    0,  244,    2, 0x08 /* Private */,
      39,    0,  245,    2, 0x08 /* Private */,
      40,    0,  246,    2, 0x08 /* Private */,
      41,    0,  247,    2, 0x08 /* Private */,
      42,    0,  248,    2, 0x08 /* Private */,
      43,    0,  249,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    7,    8,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    7,    8,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    7,    8,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void selectWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<selectWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_reset_clicked(); break;
        case 1: _t->on_selectbth_clicked(); break;
        case 2: _t->on_viewtab_clicked(); break;
        case 3: _t->qrySelection_currentRowChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 4: _t->tabSelection_currentChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 5: _t->tabSelection_currentRowChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 6: _t->comboFields_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->radioBtnAscend_clicked(); break;
        case 8: _t->radioBtnDescend_clicked(); break;
        case 9: _t->refreshTableView(); break;
        case 10: _t->on_firstrecord_clicked(); break;
        case 11: _t->on_lastrecord_clicked(); break;
        case 12: _t->on_preitem_clicked(); break;
        case 13: _t->on_nextitem_clicked(); break;
        case 14: _t->on_mohuselect_clicked(); break;
        case 15: _t->on_excelout_clicked(); break;
        case 16: { QList<std::pair<bool,int> > _r = _t->gethiden();
            if (_a[0]) *reinterpret_cast< QList<std::pair<bool,int> >*>(_a[0]) = std::move(_r); }  break;
        case 17: _t->on_printpdf_clicked(); break;
        case 18: _t->on_checkid_clicked(); break;
        case 19: _t->on_checkname_clicked(); break;
        case 20: _t->on_checktime_clicked(); break;
        case 21: _t->on_checkthing_clicked(); break;
        case 22: _t->on_checkmoney_clicked(); break;
        case 23: _t->on_checkcompany_clicked(); break;
        case 24: _t->on_checkconnect_clicked(); break;
        case 25: _t->on_checkphone_clicked(); break;
        case 26: _t->on_checknum_clicked(); break;
        case 27: _t->on_checkoperator_clicked(); break;
        case 28: _t->on_checkfeiliao_clicked(); break;
        case 29: _t->on_checkwater_clicked(); break;
        case 30: _t->on_checkgrowth_clicked(); break;
        case 31: _t->on_checkothers_clicked(); break;
        case 32: _t->sethead(); break;
        case 33: _t->on_printpdf_2_clicked(); break;
        case 34: _t->on_shouge_clicked(); break;
        case 35: _t->on_gengxin_clicked(); break;
        case 36: _t->on_del_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject selectWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_selectWidget.data,
    qt_meta_data_selectWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *selectWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *selectWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_selectWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int selectWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 37;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
