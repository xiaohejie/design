/****************************************************************************
** Meta object code from reading C++ file 'uidemo18.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../uidemo18.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'uidemo18.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_UIDemo18_t {
    QByteArrayData data[24];
    char stringdata0[455];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UIDemo18_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UIDemo18_t qt_meta_stringdata_UIDemo18 = {
    {
QT_MOC_LITERAL(0, 0, 8), // "UIDemo18"
QT_MOC_LITERAL(1, 9, 11), // "quit_Signal"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 8), // "initForm"
QT_MOC_LITERAL(4, 31, 7), // "initNav"
QT_MOC_LITERAL(5, 39, 18), // "on_whether_clicked"
QT_MOC_LITERAL(6, 58, 17), // "on_btnMsg_clicked"
QT_MOC_LITERAL(7, 76, 20), // "on_btnReturn_clicked"
QT_MOC_LITERAL(8, 97, 25), // "btn_Product_Clicked_slots"
QT_MOC_LITERAL(9, 123, 22), // "btn_Info_Clicked_slots"
QT_MOC_LITERAL(10, 146, 26), // "btn_Research_Clicked_slots"
QT_MOC_LITERAL(11, 173, 21), // "btn_Map_Clicked_slots"
QT_MOC_LITERAL(12, 195, 26), // "btn_Analysis_Clicked_slots"
QT_MOC_LITERAL(13, 222, 22), // "btn_QGIS_Clicked_slots"
QT_MOC_LITERAL(14, 245, 26), // "btn_Settings_Clicked_slots"
QT_MOC_LITERAL(15, 272, 24), // "on_btn_AddAcount_clicked"
QT_MOC_LITERAL(16, 297, 15), // "on_help_clicked"
QT_MOC_LITERAL(17, 313, 15), // "on_rili_clicked"
QT_MOC_LITERAL(18, 329, 18), // "on_btnQuit_clicked"
QT_MOC_LITERAL(19, 348, 24), // "on_btn_AddFlower_clicked"
QT_MOC_LITERAL(20, 373, 24), // "on_btn_cleartext_clicked"
QT_MOC_LITERAL(21, 398, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(22, 420, 25), // "on_pushButton_map_clicked"
QT_MOC_LITERAL(23, 446, 8) // "userinfo"

    },
    "UIDemo18\0quit_Signal\0\0initForm\0initNav\0"
    "on_whether_clicked\0on_btnMsg_clicked\0"
    "on_btnReturn_clicked\0btn_Product_Clicked_slots\0"
    "btn_Info_Clicked_slots\0"
    "btn_Research_Clicked_slots\0"
    "btn_Map_Clicked_slots\0btn_Analysis_Clicked_slots\0"
    "btn_QGIS_Clicked_slots\0"
    "btn_Settings_Clicked_slots\0"
    "on_btn_AddAcount_clicked\0on_help_clicked\0"
    "on_rili_clicked\0on_btnQuit_clicked\0"
    "on_btn_AddFlower_clicked\0"
    "on_btn_cleartext_clicked\0on_pushButton_clicked\0"
    "on_pushButton_map_clicked\0userinfo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UIDemo18[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    0,  130,    2, 0x08 /* Private */,
       9,    0,  131,    2, 0x08 /* Private */,
      10,    0,  132,    2, 0x08 /* Private */,
      11,    0,  133,    2, 0x08 /* Private */,
      12,    0,  134,    2, 0x08 /* Private */,
      13,    0,  135,    2, 0x08 /* Private */,
      14,    0,  136,    2, 0x08 /* Private */,
      15,    0,  137,    2, 0x08 /* Private */,
      16,    0,  138,    2, 0x08 /* Private */,
      17,    0,  139,    2, 0x08 /* Private */,
      18,    0,  140,    2, 0x08 /* Private */,
      19,    0,  141,    2, 0x08 /* Private */,
      20,    0,  142,    2, 0x08 /* Private */,
      21,    0,  143,    2, 0x08 /* Private */,
      22,    0,  144,    2, 0x08 /* Private */,
      23,    0,  145,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void UIDemo18::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<UIDemo18 *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->quit_Signal(); break;
        case 1: _t->initForm(); break;
        case 2: _t->initNav(); break;
        case 3: _t->on_whether_clicked(); break;
        case 4: _t->on_btnMsg_clicked(); break;
        case 5: _t->on_btnReturn_clicked(); break;
        case 6: _t->btn_Product_Clicked_slots(); break;
        case 7: _t->btn_Info_Clicked_slots(); break;
        case 8: _t->btn_Research_Clicked_slots(); break;
        case 9: _t->btn_Map_Clicked_slots(); break;
        case 10: _t->btn_Analysis_Clicked_slots(); break;
        case 11: _t->btn_QGIS_Clicked_slots(); break;
        case 12: _t->btn_Settings_Clicked_slots(); break;
        case 13: _t->on_btn_AddAcount_clicked(); break;
        case 14: _t->on_help_clicked(); break;
        case 15: _t->on_rili_clicked(); break;
        case 16: _t->on_btnQuit_clicked(); break;
        case 17: _t->on_btn_AddFlower_clicked(); break;
        case 18: _t->on_btn_cleartext_clicked(); break;
        case 19: _t->on_pushButton_clicked(); break;
        case 20: _t->on_pushButton_map_clicked(); break;
        case 21: _t->userinfo(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (UIDemo18::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UIDemo18::quit_Signal)) {
                *result = 0;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject UIDemo18::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_UIDemo18.data,
    qt_meta_data_UIDemo18,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *UIDemo18::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UIDemo18::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_UIDemo18.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int UIDemo18::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void UIDemo18::quit_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
