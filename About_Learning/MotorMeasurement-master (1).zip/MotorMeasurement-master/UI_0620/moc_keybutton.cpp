/****************************************************************************
** Meta object code from reading C++ file 'keybutton.h'
**
** Created: Sat May 30 08:08:38 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "keybutton.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'keybutton.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_keyButton[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,   37,   37,   37, 0x0a,
      38,   64,   37,   37, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_keyButton[] = {
    "keyButton\0resizeEvent(QResizeEvent*)\0"
    "\0keyPressEvent(QKeyEvent*)\0k\0"
};

void keyButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        keyButton *_t = static_cast<keyButton *>(_o);
        switch (_id) {
        case 0: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        case 1: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData keyButton::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject keyButton::staticMetaObject = {
    { &myButton::staticMetaObject, qt_meta_stringdata_keyButton,
      qt_meta_data_keyButton, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &keyButton::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *keyButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *keyButton::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_keyButton))
        return static_cast<void*>(const_cast< keyButton*>(this));
    return myButton::qt_metacast(_clname);
}

int keyButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = myButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
