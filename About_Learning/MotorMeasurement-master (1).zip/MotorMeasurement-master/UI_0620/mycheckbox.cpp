#include "mycheckbox.h"

myCheckBox::myCheckBox(QWidget *parent) :
    QCheckBox(parent)
{
}
