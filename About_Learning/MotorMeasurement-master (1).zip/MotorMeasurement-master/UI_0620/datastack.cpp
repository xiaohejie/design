#include "datastack.h"

DataStack::DataStack()
{
}
