#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0 PEout(2)	// PE2
#define LED1 PEout(3)	// PE3	

void LED_Init(void);//��ʼ��
   
#endif
