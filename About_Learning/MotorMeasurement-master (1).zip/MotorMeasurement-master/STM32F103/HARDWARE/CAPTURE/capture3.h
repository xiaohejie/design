#ifndef __CAPTURE3_H
#define __CAPTURE3_H
#include "sys.h"

void TIM3_Cap_Init(u16 arr,u16 psc);

#endif
