#ifndef __CAPTURE3RE_H
#define __CAPTURE3RE_H
#include "sys.h"

void TIM3RE_Cap_Init(u16 arr,u16 psc);

#endif
